--+++++++++++++++++++++++++++++++++++++++++--
--Estrutura do armazenamento
--Tabela de filmes e series
--
create table filme_serie (
	filme_serie_id int,
	titulo varchar(50),
	genero varchar(50),
	temporadas varchar(2),
	duracao int,
	ano_lancamento int,
	cartaz_name text,
	cartaz bytea,
	primary key (filme_serie_id)
)

--Sequencia do filme_serie_id
--
create sequence filme_serie_id;
--
--+++++++++++++++++++++++++++++++++++++++++--

--+++++++++++++++++++++++++++++++++++++++++--
--Tabela de episodios
--
create table episodio (
	episodio_id int,
	titulo varchar(50),
	num_temp int,
	duracao int,
	filme_serie_id int,
	primary key (episodio_id),
	foreign key (filme_serie_id) references filme_serie
)

--Sequencia do episodio_id
--
create sequence episodio_id;
--+++++++++++++++++++++++++++++++++++++++++--





create table ator (
	ator_id int,
	nome varchar(50),
	data_nascimento char(10),
	sexo varchar(20),
	primary key (ator_id)
)

create sequence ator_id;


create table elencoP (
	filme_serie_id int,
	ator_id int,
	primary key (filme_serie_id, ator_id),
	foreign key (filme_serie_id) references filme_serie(filme_serie_id),
	foreign key (ator_id) references ator(ator_id)
)

create table elencoS (
	filme_serie_id int,
	ator_id int,
	primary key (filme_serie_id, ator_id),
	foreign key (filme_serie_id) references filme_serie(filme_serie_id),
	foreign key (ator_id) references ator(ator_id)
)

	
create table usuario (
	usuario_id int,
	login varchar(50),
	senha varchar(50),
	data_nascimento char(10),
	primary key (usuario_id)
)


create sequence usuario_id;

create table lista_usuario (
	usuario_id int,
	filme_serie_id int,
	primary key (usuario_id, filme_serie_id),
	foreign key (usuario_id) references usuario(usuario_id),
	foreign key (filme_serie_id) references filme_serie(filme_serie_id)
)

insert into filme_serie values (nextval('filme_serie_id'), 'Harry Potter', 'Aventura', '-', 140, 2001);

insert into usuario values (nextval('usuario_id'), 'admin', '123', '29/01/2005');
delete from filme_serie where filme_serie_id = 1;
delete from elencoP where filme_serie_id = 1;
delete from lista_usuario where usuario_id = 1 and filme_serie_id = 2;

insert into lista_usuario values (2, 1);

select * from filme_serie;
select * from elencoP;
select * from ator;
select * from episodio;
select * from usuario where login = 'vinicius';
select * from lista_usuario;
drop sequence filme_serie_id;
drop table episodio;
drop sequence episodio_id;
drop table lista_usuario;