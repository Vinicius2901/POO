package dados;

import java.awt.Image;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Filme {
	private int id;
	private String titulo;
	private String genero;
	protected int duracao;
	private int anoDeLancamento;
	private List<Ator> elencoP = new ArrayList<Ator>();
	private List<Ator> elencoS = new ArrayList<Ator>();
	private Image cartaz;
	private boolean specific = false;
	private File foto;
	
	public Filme() {
		
	}
	public Filme( int id, String titulo, String genero, int duracao, int anoLancamento, Image cartaz ) {
		this.id = id;
		this.titulo = titulo;
		this.genero = genero;
		this.duracao = duracao;
		this.anoDeLancamento = anoLancamento;
		this.cartaz = cartaz;
	}
	
	public Filme( int id, String titulo, String genero, int duracao, int anoLancamento, Image cartaz, File foto ) {
		this.id = id;
		this.titulo = titulo;
		this.genero = genero;
		this.duracao = duracao;
		this.anoDeLancamento = anoLancamento;
		this.cartaz = cartaz;
		this.foto = foto;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}
	public int getDuracao() {
		return duracao;
	}
	public void setDuracao(int duracao) {
		this.duracao = duracao;
	}
	public int getAnoDeLancamento() {
		return anoDeLancamento;
	}
	public void setAnoDeLancamento(int anoDeLancamento) {
		this.anoDeLancamento = anoDeLancamento;
	}
	public List<Ator> getElencoP() {
		return elencoP;
	}
	public void setElencoP(List<Ator> elencoP) {
		this.elencoP = elencoP;
	}
	public List<Ator> getElencoS() {
		return elencoS;
	}
	public void setElencoS(List<Ator> elencoS) {
		this.elencoS = elencoS;
	}
	public boolean isSpecific() {
		return specific;
	}
	public void setSpecific(boolean specific) {
		this.specific = specific;
	}
	public Image getCartaz() {
		return cartaz;
	}
	public void setCartaz(Image cartaz) {
		this.cartaz = cartaz;
	}
	public File getFoto() {
		return foto;
	}
	public void setFoto(File foto) {
		this.foto = foto;
	}

	public String toString() {
		String filme = "\n";
		filme += "ID: #" + id + "\n";
		filme += "Titulo: " + titulo + "\n";
		filme += "Genero: " + genero + "\n";
		filme += "Duracao: " + duracao + "min\n";
		filme += "Ano de Lancamento: " + anoDeLancamento + "\n";
		if( specific == true ) {
			filme += "Elenco principal: " + elencoP + "\n";
			filme += "Elenco secundario: " + elencoS;
			specific = false;
		}
		
		return filme;
	}
	@Override
	public int hashCode() {
		return Objects.hash(titulo);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Filme other = (Filme) obj;
		return Objects.equals(titulo, other.titulo) || this.id == other.id;
	}

	
	
	
}
