package dados;

import java.util.Objects;

public class Episodio implements Comparable<Object> {
	private Serie serie;
	private int id;
	private String titulo;
	private int numTemp;
	private int duracao;
	
	public Episodio( int id, String titulo, int numTemp, int duracao ) {
		this.id = id;
		this.titulo = titulo;
		this.numTemp = numTemp;
		this.duracao = duracao;
	}
	
	public Episodio( int id, Serie serie, String titulo, int numTemp, int duracao ) {
		this.id = id;
		this.serie = serie;
		this.titulo = titulo;
		this.numTemp = numTemp;
		this.duracao = duracao;
	}
	
	public Episodio() {
		
	}
	
	public Serie getSerie() {
		return serie;
	}
	public void setSerie(Serie serie) {
		this.serie = serie;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public int getNumTemp() {
		return numTemp;
	}
	public void setNumTemp(int numTemp) {
		this.numTemp = numTemp;
	}
	public int getDuracao() {
		return duracao;
	}
	public void setDuracao(int duracao) {
		this.duracao = duracao;
	}

	public String toString() {
		String ep = "";
		ep += "ID: #" + id + "\tSerie: " + serie.getTitulo() + "\tTitulo: " + titulo;
		ep += "\tTemporada: " + numTemp + "\tDuracao: " + duracao + "\n";
		return ep;
	}

	public int compareTo(Object o) {
		Episodio e = (Episodio) o;
		if( this.numTemp != e.numTemp ) {
			return Integer.compare( this.numTemp, e.numTemp );
		}
		return Integer.compare(this.id, e.id);
	}

	@Override
	public int hashCode() {
		return Objects.hash(titulo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Episodio other = (Episodio) obj;
		return Objects.equals(titulo, other.titulo);
	}
	
	
	
	
	
}
