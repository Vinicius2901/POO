package dados;

import java.awt.Image;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Serie extends Filme {
	private int temporadas;
	private List<Episodio> episodios = new ArrayList<Episodio>();
	
	public Serie() {
		
	}
	
	public Serie( int id, String titulo, String genero, int temp, int duracao, int anoLancamento, Image cartaz ) {
		super(id, titulo, genero, duracao, anoLancamento, cartaz);
		this.temporadas = temp;
	}
	public Serie( int id, String titulo, String genero, int temp, int duracao, int anoLancamento, Image cartaz, File foto ) {
		super(id, titulo, genero, duracao, anoLancamento, cartaz, foto);
		this.temporadas = temp;
	}

	public List<Episodio> getEpisodios() {
		return episodios;
	}
	public void setEpisodios(List<Episodio> episodios) {
		this.episodios = episodios;
	}
	public int getTemporadas() {
		return temporadas;
	}
	public void setTemporadas(int temporadas) {
		this.temporadas = temporadas;
	}
	
	
	// Cadastra episódio na série de forma ordenada (De acordo com a temporada e ordem de eps craidos) e acrescenta a duração:
	public void cadastrarEp( Episodio ep ) {
		int index = 0;
		duracao += ep.getDuracao();
		if( episodios != null ) {
			index = Math.abs(Collections.binarySearch(episodios, ep)) - 1;
			/*if( index < 0 ) {
				index = -index;
			}*/
		}
		episodios.add(index, ep);
	}
	
	// Remove episódio da série e decrementa a duração:
	public boolean removerEp( Episodio ep ) {
		duracao -= ep.getDuracao();
		return episodios.remove(ep);
	}
	
	public String toString() {
		return super.toString() + "\nTemporadas: " + temporadas + "\nEpisodios: " + episodios;
	}
}
