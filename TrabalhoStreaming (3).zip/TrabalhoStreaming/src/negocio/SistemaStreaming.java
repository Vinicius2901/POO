package negocio;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import dados.Ator;
import dados.Episodio;
import dados.Filme;
import dados.Serie;
import dados.Usuario;
import exceptions.InsertException;
import exceptions.SelectException;
import persistencia.AtorDAO;
import persistencia.Conexao;
import persistencia.ElencoPDAO;
import persistencia.ElencoSDAO;
import persistencia.EpisodioDAO;
import persistencia.FilmeSerieDAO;
import persistencia.ListaUsuarioDAO;
import persistencia.UsuarioDAO;

public class SistemaStreaming {
	private static SistemaStreaming instance = null;
	private List<Usuario> usuarios = new LinkedList<Usuario>();
	private List<Filme> filmes = new ArrayList<Filme>();
	private List<Ator> atoresCadastrados = new ArrayList<>();
	private List<Episodio> epsCadastrados = new LinkedList<>();
	private Usuario logadoAtual;
	private AtorDAO atorDAO;
	private ElencoPDAO elencoPDAO;
	private ElencoSDAO elencoSDAO;
	private EpisodioDAO episodioDAO;
	private FilmeSerieDAO filmeSerieDAO;
	private ListaUsuarioDAO listaUsuarioDAO;
	private UsuarioDAO usuarioDAO;
	
	private SistemaStreaming( String senha ) {
		try {
			Conexao.setSenha(senha);
			atorDAO = AtorDAO.getInstance();
			elencoPDAO = ElencoPDAO.getInstance();
			elencoSDAO = ElencoSDAO.getInstance();
			episodioDAO = EpisodioDAO.getInstance();
			listaUsuarioDAO = ListaUsuarioDAO.getInstance();
			filmeSerieDAO = FilmeSerieDAO.getInstance();
			usuarioDAO = UsuarioDAO.getInstance();
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static SistemaStreaming getInstance() {
		if( instance == null ) {
			instance = new SistemaStreaming("290105");
		}
		return instance;
	}
	
	// Loga como um dos usuários já criados:
	public boolean login( String nome, String senha ) {
		try {
			logadoAtual = usuarioDAO.select(nome, senha);
			if( logadoAtual == null ) {
				return false;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return true;
	}
	
	// Desloga do usuário conectado:
	public void logout() {
		logadoAtual = null;
	}
	
	// Cadastra usuário:
	public boolean criarUsuario( Usuario usuario ) {
		try {
			Usuario usuario1 = usuarioDAO.selectConta(usuario.getLogin(), usuario.getSenha());
			if( usuario1 != null ) {
				return false;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		try {
			usuarioDAO.insert(usuario);
		} catch (Exception e1) {
			System.out.println(e1.getMessage());
		}
		return true;
	}
	
	// Deleta um usuário:
	public boolean deletaUsuario( Usuario usuario ) {	
		try {
			usuarioDAO.delete(usuario);
			listaUsuarioDAO.delete(usuario);
			return true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return false;
	}
	
	// Adiciona um filme ou série ao catálogo:
	public void adicionarFilmeOuSerie( Filme filme ) {
		try {
			filmeSerieDAO.insert(filme);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	// Adiciona um ep a uma série:
	public boolean adicionarEp( Filme filme, Episodio episodio ) {
		if( !(filme instanceof Serie) ) {
			return false;
		}
		Serie serie = (Serie) filme;
		episodio.setSerie(serie);
		try {
			episodioDAO.insert(episodio);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		epsCadastrados.add(episodio);
		return true;
	}
	
	// Exclui um filme ou uma série:
	public boolean excluirFilmeOuSerie( Filme filme ) {
//		if( filmes.contains(filme) ) {
//			filmes.remove(filme);
//			if( filme instanceof Serie ) {
//				Serie serie = (Serie) filme;
//				for( Episodio e : serie.getEpisodios() ) {
//					epsCadastrados.remove(e);
//				}
//			}
//			// Remoção do filme excluido do catálogo da lista do usuário:
//			for( Usuario u : usuarios ) {
//				if( u.getFilmes().contains( filme ) ) {
//					List<Filme> filmesUsuario = u.getFilmes();
//					filmesUsuario.remove(filme);
//					u.setFilmes(filmesUsuario);
//				}
//			}
//			return true;
//		}
//		return false;
		try {
			Filme filme1 = filmeSerieDAO.select(filme.getId());
			if( filme1 == null ) {
				return false;
			}
			filmeSerieDAO.delete(filme);
			//listaUsuarioDAO.delete(filme);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return true;
	}
	
	// Excluir um ep cadastrado:
	public boolean excluirEp( Episodio ep ) {
		for( Filme f : mostrarCatalogo() ) {
			// Verificação se é uma série:
			if( f instanceof Serie ) {
				Serie serie = (Serie) f;
				// Verificação se a série contém o ep: 
				if( serie.getEpisodios().contains(ep) ) {
					try {
						episodioDAO.delete(ep);
						return true;
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
				}
			}
		}
		return false;
	}
	
	// Busca filme ou série em específico:
	public Filme buscarFilmeOuSerie( Filme filme ) {
		filme.setSpecific(true);
		try {
			return filmeSerieDAO.select(filme.getId());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
	
	// Busca todos os filmes (apenas filmes):
	public List<Filme> buscarFilmes() {
		List<Filme> apenasFilmes = new LinkedList<Filme>();
		for( Filme f : mostrarCatalogo() ) {
			if( !(f instanceof Serie) ) {
				apenasFilmes.add(f);
			}
		}
		return apenasFilmes;
	}
	
	// Busca todas as séries (apenas séries):
	public List<Serie> buscarSeries() {
		List<Serie> apenasSeries = new LinkedList<Serie>();
		for( Filme f : mostrarCatalogo() ) {
			if( f instanceof Serie ) {
				Serie serie = (Serie) f;
				apenasSeries.add(serie);
			}
		}
		return apenasSeries;
	}
	
	// Motra todo o catálogo:
	public List<Filme> mostrarCatalogo() {
		try {
			List<Filme> filmes1 = filmeSerieDAO.selectAll();
			return filmes1;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
	
	// Adiciona um filme ou série a lista de um usuário:
	public boolean addListaUsuario( Filme filme ) {
		if( logadoAtual != null ) {
			try {
				if( mostrarCatalogo().contains(filme) && 
						!(listaUsuarioDAO.selectAll(logadoAtual.getId()).contains(filme))) {
					listaUsuarioDAO.insert(logadoAtual, filme);
				}
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
				
//				List<Filme> filmesUsuario = logadoAtual.getFilmes();
//				filmesUsuario.add(filme);
//				logadoAtual.setFilmes(filmesUsuario);
				return true;
		}
		return false;
	}
	
	// Remove um filme ou série da lista do usuário:
	public boolean removerListaUsuario( Filme filme ) {
		if( logadoAtual != null ) {
			try {
				listaUsuarioDAO.deleteLista( logadoAtual, filme );
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
		return false;
	}
	
	// Busca todos os usuários:
	public List<Usuario> getUsuarios() {
		try {
			return usuarioDAO.selectAll();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
	
	// Busca um usuário em específico:
	public Usuario buscaUsuario( Usuario usuario ) {
//		if( usuarios.contains(usuario) ) {
//			return usuarios.get(usuarios.indexOf(usuario));
//		}
//		return null;
		try {
			return usuarioDAO.select(usuario.getId());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
	
	public void cadastraAtor( Ator a ) {
		try {
			atorDAO.insert(a);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public List<Ator> getAtores() {
		try {
			return atorDAO.selectAll();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
	
	public List<Episodio> getEps() {
		List<Episodio> aux = new LinkedList<>();
		List<Episodio> eps = new LinkedList<>();
		try {
			for( Serie s : buscarSeries()) {
				aux = episodioDAO.selectAll(s);
				for( Episodio e : aux ) {
					eps.add(e);
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return eps;
	}
	
	public List<Filme> buscaListaUsuario() {
		try {
			if( logadoAtual != null ) {
				return listaUsuarioDAO.selectAll(logadoAtual.getId());
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}
	
	public Usuario getLogado() {
		return logadoAtual;
	}
	
}
