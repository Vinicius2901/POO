package apresentacao.Menu;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import apresentacao.Cadastros.CadastroAtor;
import apresentacao.Cadastros.CadastroEp;
import apresentacao.Cadastros.CadastroFilmeSerie;
import apresentacao.Cadastros.PaginaLogin;
import apresentacao.Cadastros.RemoverFilmeSerieEp;
import apresentacao.Catalogos.Catalogo;
import apresentacao.Catalogos.ListaUsuarios;
import negocio.SistemaStreaming;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Options extends JPanel {

	private static final long serialVersionUID = 1L;
	private CadastroFilmeSerie cadastroFilmeSeriePane;
	private CadastroAtor cadastroAtorPane;
	private SistemaStreaming sistema = SistemaStreaming.getInstance();
	private PaginaLogin loginPane;
	private RemoverFilmeSerieEp remFilmeSerieEpPane;
	private CadastroEp cadastroEpPane;
	private Catalogo catalogoPane;
	private ListaUsuarios listaUsuariosPane;

	public Options() {
		setSize(600,510);
		setLayout(null);
		setVisible(false);
		
		JLabel title = new JLabel("Escolha a opção que deseja:");
		title.setBounds(0, 0, 600, 37);
		title.setFont(new Font("Tahoma", Font.BOLD, 30));
		title.setHorizontalAlignment(SwingConstants.CENTER);
		add(title);
		
		JButton botCadFilmeSerie = new JButton("Cadastrar novo Filme ou Serie");
		botCadFilmeSerie.setFont(new Font("Tahoma", Font.PLAIN, 20));
		botCadFilmeSerie.setBounds(10, 48, 590, 60);
		botCadFilmeSerie.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				cadastroFilmeSeriePane.setVisible(true);
			}
		});
		add(botCadFilmeSerie);
		
		JButton botRmvFilmeSerieEp = new JButton("Remover Filme/Serie/Ep");
		botRmvFilmeSerieEp.setFont(new Font("Tahoma", Font.PLAIN, 20));
		botRmvFilmeSerieEp.setBounds(10, 119, 590, 60);
		add(botRmvFilmeSerieEp);
		botRmvFilmeSerieEp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				remFilmeSerieEpPane.setVisible(true);
			}
		});
		
		JButton botCatalogo = new JButton("Ver Catálogo");
		botCatalogo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		botCatalogo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				catalogoPane.setVisible(true);
			}
		});
		botCatalogo.setBounds(10, 190, 590, 60);
		add(botCatalogo);
		
		JButton botCadEp = new JButton("Cadastrar Episodio");
		botCadEp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				cadastroEpPane.setVisible(true);
			}
		});
		botCadEp.setFont(new Font("Tahoma", Font.PLAIN, 20));
		botCadEp.setBounds(10, 332, 590, 60);
		add(botCadEp);
		
		JButton botCadAtor = new JButton("Cadastrar ator/atriz");
		botCadAtor.setFont(new Font("Tahoma", Font.PLAIN, 20));
		botCadAtor.setBounds(10, 403, 590, 60);
		add(botCadAtor);
		botCadAtor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				cadastroAtorPane.setVisible(true);
			}
	});
		
		JButton botLogout = new JButton("Logut");
		botLogout.setBounds(0, 11, 83, 23);
		add(botLogout);
		botLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sistema.logout();
				setVisible(false);
				loginPane.setVisible(true);
			}
		});
		
		JButton botUsuario = new JButton("Ver Usuários");
		botUsuario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				listaUsuariosPane.setVis(true);
				listaUsuariosPane.setVisible(true);
				listaUsuariosPane.changeVisibility();
				setVisible(false);
			}
		});
		botUsuario.setFont(new Font("Tahoma", Font.PLAIN, 20));
		botUsuario.setBounds(10, 261, 590, 60);
		add(botUsuario);
		
		
		
	}

	public void setCadastroFilmeSeriePane(CadastroFilmeSerie cadastroFilmeSeriePane) {
		this.cadastroFilmeSeriePane = cadastroFilmeSeriePane;
	}

	public void setCadastroAtorPane(CadastroAtor cadastroAtorPane) {
		this.cadastroAtorPane = cadastroAtorPane;
	}

	public void setLoginPane(PaginaLogin loginPane) {
		this.loginPane = loginPane;
	}

	public void setRemFilmeSeriePane(RemoverFilmeSerieEp remFilmeSerieEpPane) {
		this.remFilmeSerieEpPane = remFilmeSerieEpPane;
	}

	public void setCadastroEpPane(CadastroEp cadastroEpPane) {
		this.cadastroEpPane = cadastroEpPane;
	}

	public void setCatalogoPane(Catalogo catalogoPane) {
		this.catalogoPane = catalogoPane;
	}

	public void setListaUsuariosPane(ListaUsuarios listaUsuariosPane) {
		this.listaUsuariosPane = listaUsuariosPane;
	}
	
	
	
	
}
