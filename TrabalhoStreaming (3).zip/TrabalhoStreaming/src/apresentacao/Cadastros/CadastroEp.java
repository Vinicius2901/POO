package apresentacao.Cadastros;

import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;

import apresentacao.Catalogos.CatalogoSerie;
import apresentacao.Menu.Options;
import apresentacao.Tabelas.TabelaEps;
import apresentacao.Tabelas.TabelaSeries;
import dados.Episodio;
import dados.Serie;
import negocio.SistemaStreaming;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CadastroEp extends JPanel {

	private static final long serialVersionUID = 1L;
	private Options opcoesAdmPane;
	private JTextField textTitulo;
	private JTextField textNumTemp;
	private JTextField textDuracao;
	private int id = 0;
	private SistemaStreaming sistema = SistemaStreaming.getInstance();
	private TabelaSeries series;
	private TabelaEps eps;
	private CatalogoSerie catalogoSeriePane;
	private JTable tabelaSeries;
	
	public CadastroEp() {
		setVisible(false);
		setSize(800,100);
		setLayout(null);
		
		JLabel title = new JLabel("Digite as informações do Episódio:");
		title.setHorizontalAlignment(SwingConstants.CENTER);
		title.setFont(new Font("Tahoma", Font.BOLD, 30));
		title.setBounds(0, 0, 800, 37);
		add(title);
		
		JLabel tituloLabel = new JLabel("Titulo:");
		tituloLabel.setHorizontalAlignment(SwingConstants.CENTER);
		tituloLabel.setBounds(0, 48, 200, 20);
		add(tituloLabel);
		
		textTitulo = new JTextField();
		textTitulo.setColumns(10);
		textTitulo.setBounds(10, 69, 186, 20);
		add(textTitulo);
		
		JLabel botNumTemp = new JLabel("Numero da temporada:");
		botNumTemp.setHorizontalAlignment(SwingConstants.CENTER);
		botNumTemp.setBounds(96, 48, 429, 20);
		add(botNumTemp);
		
		textNumTemp = new JTextField();
		textNumTemp.setColumns(10);
		textNumTemp.setBounds(271, 69, 75, 20);
		add(textNumTemp);
		
		JLabel duracaoLabel = new JLabel("Duração:");
		duracaoLabel.setHorizontalAlignment(SwingConstants.CENTER);
		duracaoLabel.setBounds(358, 48, 200, 20);
		add(duracaoLabel);
		
		textDuracao = new JTextField();
		textDuracao.setColumns(10);
		textDuracao.setBounds(423, 69, 75, 20);
		add(textDuracao);
		
		JButton botVoltar = new JButton("Voltar");
		botVoltar.setBounds(10, 15, 82, 23);
		add(botVoltar);
		botVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textTitulo.setText("");
				textDuracao.setText("");
				textNumTemp.setText("");
				//textSerie.setText("");
				catalogoSeriePane.setVis(false);
				catalogoSeriePane.changeVisibility();
				setVisible(false);
				opcoesAdmPane.setVisible(true);
			}
		});
		
		
		JButton botCadastro = new JButton("Cadastrar Episódio");
		botCadastro.setBounds(583, 77, 150, 23);
		add(botCadastro);
		
		JButton botSeries = new JButton("Mostrar Series");
		botSeries.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				catalogoSeriePane.setVis(true);
				catalogoSeriePane.changeVisibility();
			}
		});
		botSeries.setBounds(583, 48, 150, 23);
		add(botSeries);
		botCadastro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int duracao = 0, numTemp = 0;
				if( !textTitulo.getText().equals("") && !textNumTemp.getText().equals("")
						&& !textDuracao.getText().equals("") && tabelaSeries.getSelectedRow() != -1) {
					
					try {
						duracao = Integer.parseInt(textDuracao.getText());
					}
					catch( NumberFormatException e1 ) {
						JOptionPane.showMessageDialog(null, "Duracao deve ser um número inteiro!", "Problem!", JOptionPane.INFORMATION_MESSAGE);
						textDuracao.setText("");
					}
					try {
						numTemp = Integer.parseInt(textNumTemp.getText());
					}
					catch( NumberFormatException e1 ) {
						JOptionPane.showMessageDialog(null, "Duracao deve ser um número inteiro!", "Problem!", JOptionPane.INFORMATION_MESSAGE);
						textNumTemp.setText("");
					}
					int linhaSelecionada = tabelaSeries.getSelectedRow();
	        		Serie serie = (Serie)tabelaSeries.getModel().getValueAt(linhaSelecionada, -1);
					if( sistema.buscarSeries().contains(serie) ) {
						Episodio ep = new Episodio();
						ep.setId(id);
						id++;
						ep.setTitulo(textTitulo.getText());
						ep.setDuracao(duracao);
						ep.setNumTemp(numTemp);
						serie = sistema.buscarSeries().get(sistema.buscarSeries().indexOf(serie));
						sistema.adicionarEp(serie, ep);
						series.atualiza();
						eps.add();
						textTitulo.setText("");
						textDuracao.setText("");
						textNumTemp.setText("");
						//textSerie.setText("");
						JOptionPane.showMessageDialog(null, "Episódio cadastrado com sucesso!");
						catalogoSeriePane.setVis(false);
						catalogoSeriePane.changeVisibility();
						setVisible(false);
						opcoesAdmPane.setVisible(true);
					}
					else {
						JOptionPane.showMessageDialog(null, "O nome da série está errado ou ela não existe!");
					}
				}
				else {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos!");
				}
			}
		});
	}
	
	public void setOpcoesAdmPane( Options o ) {
		this.opcoesAdmPane = o;
	}
	public void setSeries( TabelaSeries s ) {
		this.series = s;
	}
	public void setEps(TabelaEps eps) {
		this.eps = eps;
	}

	public void setCatalogoSeriePane(CatalogoSerie catalogoSeriePane) {
		this.catalogoSeriePane = catalogoSeriePane;
	}

	public void setTabelaSeries(JTable tabelaSeries) {
		this.tabelaSeries = tabelaSeries;
	}
	
	
}
