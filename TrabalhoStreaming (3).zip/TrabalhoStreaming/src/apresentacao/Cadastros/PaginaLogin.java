package apresentacao.Cadastros;

import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextField;

import apresentacao.Menu.Options;
import apresentacao.Tabelas.TabelaLista;
import dados.Usuario;
import negocio.SistemaStreaming;

public class PaginaLogin extends JPanel {
	
	private static final long serialVersionUID = 1L;
	private JTextField textLogin;
	private JPasswordField textSenha;
	private PaginaCadastro cadastroPane;
	private SistemaStreaming sistema = SistemaStreaming.getInstance();
	private Options opcoesAdmPane;
	private TabelaLista listaUsuario;
	//private PaginaCadastro = new PaginaCadastro();

	public PaginaLogin() {
		setVisible(true);
		setLayout(null);
		setSize(800,600);
		
		JLabel cadastro = new JLabel("Sem cadastro? Clique no botão abaixo para se cadastrar!");
		cadastro.setBounds(245, 135, 400, 15);
		add(cadastro);
		
		JButton botCadastro = new JButton("Cadastre-se!");
		botCadastro.setBounds(305, 164, 150, 25);
		add(botCadastro);
		botCadastro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				
				cadastroPane.setVisible(true);
			}
		});
		
		JLabel login = new JLabel("Nome de usuario:");
		login.setBounds(275, 234, 120, 15);
		add(login);
		
		textLogin = new JTextField();
		textLogin.setBounds(275, 264, 210, 20);
		add(textLogin);
		textLogin.setColumns(10);
		
		JLabel Senha = new JLabel("Senha:");
		Senha.setBounds(275, 294, 50, 15);
		add(Senha);
		
		textSenha = new JPasswordField();
		textSenha.setBounds(275, 314, 210, 20);
		add(textSenha);
		textSenha.setColumns(10);
		
		JButton entrar = new JButton("Login");
		entrar.setBounds(275, 344, 90, 25);
		add(entrar);
		entrar.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent arg0) {
		        Usuario user = new Usuario();
		        String name = textLogin.getText();
		        user.setNome(name);
		        char[] senha = textSenha.getPassword();
		        String pass = new String(senha);
		        user.setSenha(pass);

		        if (name.equals("")) {
		            JOptionPane.showMessageDialog(null, "Digite algo como nome de usuário!");
		        }
		        else if (pass.equals("")) {
		            JOptionPane.showMessageDialog(null, "Digite algo como senha!");
		        } 
		        else if (!sistema.login(name, pass)) {
		            JOptionPane.showMessageDialog(null, "Login ou senha estão errados!");
		        }
		        else {
		            sistema.login(name, pass);
		            listaUsuario.atualiza();
		            textLogin.setText("");
		            textSenha.setText("");
		            setVisible(false);
		            opcoesAdmPane.setVisible(true);
		        }
		    }
		});

	}
	public void setCadastroPane( PaginaCadastro pc ) {
		this.cadastroPane = pc;
	}
	public void setOpcoesAdmPane( Options o ) {
		this.opcoesAdmPane = o;
	}
	public void setListaUsuario( TabelaLista t ) {
		listaUsuario = t;
	}
}
