package apresentacao.Cadastros;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import apresentacao.Menu.Options;
import apresentacao.Tabelas.TabelaFilmes;
import apresentacao.Tabelas.TabelaSeries;
import dados.Ator;
import dados.Filme;
import dados.Serie;
import negocio.SistemaStreaming;
import persistencia.FilmeSerieDAO;

import java.awt.Font;
import java.awt.Image;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class CadastroFilmeSerie extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTextField tituloText;
	private JTextField anoLancamentoText;
	private JTextField duracaoText;
	private JTextField generoText;
	private JTextField elencoPText;
	private JTextField elencoSText;
	private int id = 0;
	private SistemaStreaming sistema = SistemaStreaming.getInstance();
	private CadastroAtor cadastroAtorPane;
	private boolean cadastrando = false;
	private boolean cadastrado = false;
	private Options opcoesAdmPane;
	private TabelaFilmes filmes;
	private TabelaSeries series;
	private JFileChooser cartazGetter = new JFileChooser();
	private Image cartaz = null;
	private JLabel nomeArq = new JLabel();
	private JTextField temporadasText;
	FilmeSerieDAO filmeSerieDAO;

	public CadastroFilmeSerie() {
		setSize(800,600);
		setLayout(null);
		setVisible(false);
		
		JLabel title = new JLabel("Digite as informações do filme ou série:");
		title.setBounds(0, 0, 800, 37);
		title.setFont(new Font("Tahoma", Font.BOLD, 30));
		title.setHorizontalAlignment(SwingConstants.CENTER);
		add(title);
		
		JLabel tituloLabel = new JLabel("Titulo:");
		tituloLabel.setBounds(0, 37, 800, 20);
		tituloLabel.setHorizontalAlignment(SwingConstants.CENTER);
		add(tituloLabel);
		
		tituloText = new JTextField();
		tituloText.setBounds(235, 68, 335, 20);
		add(tituloText);
		tituloText.setColumns(10);
		
		JLabel anoLancamentoLabel = new JLabel("Ano de lançamento:");
		anoLancamentoLabel.setHorizontalAlignment(SwingConstants.CENTER);
		anoLancamentoLabel.setBounds(0, 99, 800, 20);
		add(anoLancamentoLabel);
		
		anoLancamentoText = new JTextField();
		anoLancamentoText.setBounds(235, 130, 335, 20);
		add(anoLancamentoText);
		anoLancamentoText.setColumns(10);
		
		JLabel duracaoLabel = new JLabel("Duração:");
		duracaoLabel.setHorizontalAlignment(SwingConstants.CENTER);
		duracaoLabel.setBounds(0, 161, 800, 20);
		add(duracaoLabel);
		
		duracaoText = new JTextField();
		duracaoText.setColumns(10);
		duracaoText.setBounds(235, 192, 335, 20);
		add(duracaoText);
		
		JLabel generoLabel = new JLabel("Gênero:");
		generoLabel.setHorizontalAlignment(SwingConstants.CENTER);
		generoLabel.setBounds(0, 281, 800, 20);
		add(generoLabel);
		
		generoText = new JTextField();
		generoText.setColumns(10);
		generoText.setBounds(235, 312, 335, 20);
		add(generoText);
		
		JLabel elencoPLabel = new JLabel("Elenco Principal:");
		elencoPLabel.setHorizontalAlignment(SwingConstants.CENTER);
		elencoPLabel.setBounds(0, 332, 800, 20);
		add(elencoPLabel);
		
		elencoPText = new JTextField();
		elencoPText.setColumns(10);
		elencoPText.setBounds(235, 363, 335, 20);
		add(elencoPText);
		
		JLabel elencoSLabel = new JLabel("Elenco Secundário:");
		elencoSLabel.setHorizontalAlignment(SwingConstants.CENTER);
		elencoSLabel.setBounds(0, 394, 800, 20);
		add(elencoSLabel);
		
		elencoSText = new JTextField();
		elencoSText.setColumns(10);
		elencoSText.setBounds(235, 425, 335, 20);
		add(elencoSText);
		
		JButton botCadastroFilme = new JButton("Cadastrar Filme");
		botCadastroFilme.setBounds(420, 500, 150, 23);
		add(botCadastroFilme);
		
		JButton botCadastroSerie = new JButton("Cadastrar Serie");
		botCadastroSerie.setBounds(235, 500, 150, 23);
		add(botCadastroSerie);
		
		JButton botVoltar = new JButton("Voltar");
		botVoltar.setBounds(10, 15, 82, 23);
		add(botVoltar);
		
		add(nomeArq);
		
		JButton buscaCartaz = new JButton("Escolha a imagem de cartaz");
		buscaCartaz.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int foi = cartazGetter.showOpenDialog(buscaCartaz);
				if( foi != JFileChooser.APPROVE_OPTION ) {
					return;
				}
				else {
					try{
	                    File f = cartazGetter.getSelectedFile();
	                    cartaz = ImageIO.read(f);
	                    nomeArq.setText(f.getName());
	                }catch(IOException exception){
	                    System.out.println("Algo deu errado ao tentar inserir a imagem!");
	                }
				}
			}
		});
		buscaCartaz.setBounds(235, 456, 335, 33);
		add(buscaCartaz);
		
		JLabel temporadasLabel = new JLabel("Temporadas(Serie):");
		temporadasLabel.setHorizontalAlignment(SwingConstants.CENTER);
		temporadasLabel.setBounds(0, 219, 800, 20);
		add(temporadasLabel);
		
		temporadasText = new JTextField();
		temporadasText.setColumns(10);
		temporadasText.setBounds(235, 250, 335, 20);
		add(temporadasText);
		botVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tituloText.setText("");
				anoLancamentoText.setText("");
				duracaoText.setText("");
				generoText.setText("");
				elencoPText.setText("");
				elencoSText.setText("");
				setVisible(false);
				opcoesAdmPane.setVisible(true);
			}
		});
		
		botCadastroFilme.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int duracao = 0, anoLancamento = 0;
				cadastrado = false;
				cadastrando = true;
				if( !tituloText.getText().equals("") && !anoLancamentoText.getText().equals("") &&
						!duracaoText.getText().equals("") && !generoText.getText().equals("") && 
						!elencoPText.getText().equals("") && !elencoSText.getText().equals("") &&
						cartaz != null ) {
					try {
						duracao = Integer.parseInt(duracaoText.getText());
					}
					catch( NumberFormatException e ) {
						JOptionPane.showMessageDialog(null, "Duracao deve ser um número inteiro!", "Problem!", JOptionPane.INFORMATION_MESSAGE);
						duracaoText.setText("");
						
					}
					try {
						anoLancamento = Integer.parseInt(anoLancamentoText.getText());
					}
					catch( NumberFormatException e ) {
						JOptionPane.showMessageDialog(null, "Ano de lançamento deve ser um número inteiro!", "Problem!", JOptionPane.INFORMATION_MESSAGE);
						anoLancamentoText.setText("");
					}
					String titulo = tituloText.getText();
					String elencoP = elencoPText.getText();
					String elencoS = elencoSText.getText();
					String listElencoP[] = elencoP.split(",");
					String listElencoS[] = elencoS.split(",");
					List<Ator> elencoPrin = new ArrayList<>();
					List<Ator> elencoSec = new ArrayList<>();
					for( String s : listElencoP ) {
						Ator ator = new Ator();
						ator.setNome(s);
						if( sistema.getAtores().contains(ator) ) {
							ator = sistema.getAtores().get(sistema.getAtores().indexOf(ator));
							elencoPrin.add(ator);
							cadastrado = true;
						}
						else {
							cadastrado = false;
							int opt = JOptionPane.showConfirmDialog(null, "Ator \"" + s + "\" não cadastrado no sistema, deseja cadastrar?");
							switch(opt) {
							case 0:
								cadastroAtorPane.setNomeText(s);
								setVisible(false);
								cadastroAtorPane.setVisible(true);
								break;
							}
							break;
						}
					}
					if( cadastrado ) {
						for( String s : listElencoS ) {
							Ator ator = new Ator();
							ator.setNome(s);
							if( sistema.getAtores().contains(ator) ) {
								ator = sistema.getAtores().get(sistema.getAtores().indexOf(ator));
								cadastrado = true;
								elencoSec.add(ator);
							}
							else {
								cadastrado = false;
								int opt = JOptionPane.showConfirmDialog(null, "Ator \"" + s + "\" não cadastrado no sistema, deseja cadastrar?");
								switch(opt) {
								case 0:
									cadastroAtorPane.setNomeText(s);
									setVisible(false);
									cadastroAtorPane.setVisible(true);
									break;
								}
								break;
							}
						}
					}
					if( cadastrado ) {
						Filme filme = new Filme();
						String genero = generoText.getText();
						File foto = cartazGetter.getSelectedFile();
						filme.setCartaz(cartaz);
						filme.setId(id);
						id++;
						filme.setTitulo(titulo);
						filme.setAnoDeLancamento(anoLancamento);
						filme.setDuracao(duracao);
						filme.setGenero(genero);
						filme.setElencoP(elencoPrin);
						filme.setElencoS(elencoSec);
						filme.setFoto(foto);
						sistema.adicionarFilmeOuSerie(filme);
						filmes.add();
						tituloText.setText("");
						anoLancamentoText.setText("");
						duracaoText.setText("");
						generoText.setText("");
						elencoPText.setText("");
						elencoSText.setText("");
						nomeArq.setText("");
						cartaz = null;
						cartazGetter.setSelectedFile(null);
						setVisible(false);
						opcoesAdmPane.setVisible(true);
						JOptionPane.showMessageDialog(null, "Filme cadastrado com sucesso!");
						cadastrando = false;
					}
				}
				else {
					JOptionPane.showMessageDialog(null, "Algum dos campos não está preenchido!");
				}
			}
		});
		botCadastroSerie.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int anoLancamento = 0;
				int temporadas = 0;
				cadastrado = false;
				cadastrando = true;
				if( !tituloText.getText().equals("") && !anoLancamentoText.getText().equals("")
						&& !generoText.getText().equals("") && !elencoPText.getText().equals("")
						&& !elencoSText.getText().equals("") && !temporadasText.equals("") ) {
					
					try {
						anoLancamento = Integer.parseInt(anoLancamentoText.getText());
					}
					catch( NumberFormatException e ) {
						JOptionPane.showMessageDialog(null, "Ano de lançamento deve ser um número inteiro!", "Problem!", JOptionPane.INFORMATION_MESSAGE);
						anoLancamentoText.setText("");
					}
					try {
						temporadas = Integer.parseInt(temporadasText.getText());
					} catch (NumberFormatException e) {
						JOptionPane.showMessageDialog(null, "Temporadas deve ser um número inteiro!", "Problem!", JOptionPane.INFORMATION_MESSAGE);
						anoLancamentoText.setText("");
					}
					String titulo = tituloText.getText();
					String elencoP = elencoPText.getText();
					String elencoS = elencoSText.getText();
					String listElencoP[] = elencoP.split(",");
					String listElencoS[] = elencoS.split(",");
					List<Ator> elencoPrin = new ArrayList<>();
					List<Ator> elencoSec = new ArrayList<>();
					for( String s : listElencoP ) {
						Ator ator = new Ator();
						ator.setNome(s);
						if( sistema.getAtores().contains(ator) ) {
							ator = sistema.getAtores().get(sistema.getAtores().indexOf(ator));
							elencoPrin.add(ator);
							cadastrado = true;
						}
						else {
							cadastrado = false;
							int opt = JOptionPane.showConfirmDialog(null, "Ator \"" + s + "\" não cadastrado no sistema, deseja cadastrar?");
							switch(opt) {
							case 0:
								cadastroAtorPane.setNomeText(s);
								setVisible(false);
								cadastroAtorPane.setVisible(true);
								break;
							}
							break;
						}
					}
					if( cadastrado ) {
						for( String s : listElencoS ) {
							Ator ator = new Ator();
							ator.setNome(s);
							if( sistema.getAtores().contains(ator) ) {
								ator = sistema.getAtores().get(sistema.getAtores().indexOf(ator));
								cadastrado = true;
								elencoSec.add(ator);
							}
							else {
								cadastrado = false;
								int opt = JOptionPane.showConfirmDialog(null, "Ator \"" + s + "\" não cadastrado no sistema, deseja cadastrar?");
								switch(opt) {
								case 0:
									cadastroAtorPane.setNomeText(s);
									setVisible(false);
									cadastroAtorPane.setVisible(true);
									break;
								}
								break;
							}
						}
					}
					if( cadastrado ) {
						Serie serie = new Serie();
						String genero = generoText.getText();
						File foto = cartazGetter.getSelectedFile();
						serie.setCartaz(cartaz);
						serie.setId(id);
						id++;
						serie.setTitulo(titulo);
						serie.setAnoDeLancamento(anoLancamento);
						serie.setDuracao(0);
						serie.setTemporadas(temporadas);
						serie.setGenero(genero);
						serie.setElencoP(elencoPrin);
						serie.setElencoS(elencoSec);
						serie.setFoto(foto);
						sistema.adicionarFilmeOuSerie(serie);
						series.add();
						tituloText.setText("");
						anoLancamentoText.setText("");
						duracaoText.setText("");
						generoText.setText("");
						elencoPText.setText("");
						elencoSText.setText("");
						temporadasText.setText("");
						nomeArq.setText(elencoS);
						cartaz = null;
						cartazGetter.setSelectedFile(null);
						setVisible(false);
						opcoesAdmPane.setVisible(true);
						JOptionPane.showMessageDialog(null, "Serie cadastrada com sucesso!");
						cadastrando = false;
					}
				}
				else {
					JOptionPane.showMessageDialog(null, "Algum dos campos não está preenchido!");
				}
			}
		});
	}
	public void setCadastroAtorPane( CadastroAtor ca ) {
		this.cadastroAtorPane = ca;
	}
	public boolean isCadastrando() {
		return cadastrando;
	}
	public boolean isCadastrado() {
		return cadastrado;
	}
	public void setOpcoesAdmPane(Options opcoesAdmPane) {
		this.opcoesAdmPane = opcoesAdmPane;
	}
	public void setFilmes(TabelaFilmes filmes) {
		this.filmes = filmes;
	}
	public void setSeries( TabelaSeries series ) {
		this.series = series;
	}
}
