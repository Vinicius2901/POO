package apresentacao.Cadastros;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.SwingConstants;

import apresentacao.Menu.Options;
import dados.Ator;
import negocio.SistemaStreaming;

import javax.swing.JTextField;
import javax.swing.JButton;

public class CadastroAtor extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTextField nomeText;
	private JTextField dataNascimentoText;
	private JTextField sexoText;
	private CadastroFilmeSerie cadastroFilmeSeriePane;
	private Options opcoesAdmPane;
	private SistemaStreaming sistema = SistemaStreaming.getInstance();
	private int id = 0;

	public CadastroAtor() {
		setSize(800,600);
		setLayout(null);
		setVisible(false);
		
		JLabel title = new JLabel("Digite as informações do ator ou da atriz:");
		title.setBounds(10, 0, 800, 37);
		title.setHorizontalAlignment(SwingConstants.CENTER);
		title.setFont(new Font("Tahoma", Font.BOLD, 30));
		add(title);
		
		JLabel nomeLabel = new JLabel("Digite o nome:");
		nomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
		nomeLabel.setBounds(0, 70, 800, 20);
		add(nomeLabel);
		
		nomeText = new JTextField();
		nomeText.setBounds(320, 100, 160, 20);
		add(nomeText);
		nomeText.setColumns(10);
		
		JLabel dataNasimentoLabel = new JLabel("Digite a data de nascimento:");
		dataNasimentoLabel.setHorizontalAlignment(SwingConstants.CENTER);
		dataNasimentoLabel.setBounds(0, 131, 800, 20);
		add(dataNasimentoLabel);
		
		dataNascimentoText = new JTextField();
		dataNascimentoText.setColumns(10);
		dataNascimentoText.setBounds(320, 161, 160, 20);
		add(dataNascimentoText);
		
		JLabel sexoLabel = new JLabel("Digite o sexo:");
		sexoLabel.setHorizontalAlignment(SwingConstants.CENTER);
		sexoLabel.setBounds(0, 192, 800, 20);
		add(sexoLabel);
		
		sexoText = new JTextField();
		sexoText.setColumns(10);
		sexoText.setBounds(320, 222, 160, 20);
		add(sexoText);
		
		JButton botCadastro = new JButton("Cadastrar");
		botCadastro.setBounds(320, 262, 160, 23);
		add(botCadastro);
		
		JButton botVoltar = new JButton("Voltar");
		botVoltar.setBounds(10, 15, 82, 23);
		add(botVoltar);
		botVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(cadastroFilmeSeriePane.isCadastrando()) {
					nomeText.setText("");
					dataNascimentoText.setText("");
					sexoText.setText("");
					setVisible(false);
					cadastroFilmeSeriePane.setVisible(true);
				}
				else {
					nomeText.setText("");
					dataNascimentoText.setText("");
					sexoText.setText("");
					setVisible(false);
					opcoesAdmPane.setVisible(true);
				}
			}
		});
		
		botCadastro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if( !nomeText.getText().equals("") && !dataNascimentoText.getText().equals("") && !sexoText.getText().equals("")  ) {
					if( cadastroFilmeSeriePane.isCadastrando() ) {
						Ator ator = new Ator();
						ator.setId(id);
						id++;
						ator.setNome(nomeText.getText());
						ator.setDataNascimento(dataNascimentoText.getText());
						ator.setSexo(sexoText.getText());
						sistema.cadastraAtor(ator);
						JOptionPane.showMessageDialog(null, "Ator cadastrado com sucesso! Clique no botão \"Cadastrar\" para seguir com o cadastro do filme");
						setVisible(false);
						cadastroFilmeSeriePane.setVisible(true);
						nomeText.setText("");
						dataNascimentoText.setText("");
						sexoText.setText("");
						
					}
					else {
						Ator ator = new Ator();
						ator.setId(id);
						id++;
						ator.setNome(nomeText.getText());
						ator.setDataNascimento(dataNascimentoText.getText());
						ator.setSexo(sexoText.getText());
						sistema.cadastraAtor(ator);
						JOptionPane.showMessageDialog(null, "Ator cadastrado com sucesso!");
						setVisible(false);
						opcoesAdmPane.setVisible(true);
						nomeText.setText("");
						dataNascimentoText.setText("");
						sexoText.setText("");
					}
				}
				else {
					JOptionPane.showMessageDialog(null, "Voce deixou algum dos campos em branco!");
				}
			}
		});
	}

	public void setCadastroFilmeSeriePane(CadastroFilmeSerie cadastroFilmeSeriePane) {
		this.cadastroFilmeSeriePane = cadastroFilmeSeriePane;
	}

	public void setOpcoesAdmPane(Options opcoesAdmPane) {
		this.opcoesAdmPane = opcoesAdmPane;
	}

	public void setNomeText(String nomeAtor) {
		this.nomeText.setText(nomeAtor);
	}
	
	
	
	

}
