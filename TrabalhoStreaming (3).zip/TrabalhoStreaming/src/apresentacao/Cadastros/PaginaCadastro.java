package apresentacao.Cadastros;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import apresentacao.Tabelas.TabelaUsuarios;
import dados.Usuario;
import negocio.SistemaStreaming;
import java.awt.Font;

public class PaginaCadastro extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTextField textLogin;
	private JPasswordField textSenha;
	private PaginaLogin loginPane;
	private JTextField textNascimento;
	private SistemaStreaming sistema = SistemaStreaming.getInstance();
	private TabelaUsuarios usuarios;

	public PaginaCadastro() {
		setVisible(false);
		setLayout(null);
		setSize(800,600);
		JLabel login = new JLabel("Digite o nome de usuario desejado:");
		login.setBounds(280, 171, 210, 15);
		add(login);
		
		textLogin = new JTextField();
		textLogin.setBounds(280, 201, 210, 20);
		add(textLogin);
		textLogin.setColumns(10);
		
		JLabel Senha = new JLabel("Digite a senha desejada:");
		Senha.setBounds(280, 231, 200, 15);
		add(Senha);
		
		textSenha = new JPasswordField();
		textSenha.setBounds(280, 251, 210, 20);
		add(textSenha);
		textSenha.setColumns(10);
		
		JButton botCadastro = new JButton("Cadastrar");
		botCadastro.setBounds(280, 338, 90, 25);
		add(botCadastro);
		
		JLabel cadastro = new JLabel("Cadastro:");
		cadastro.setFont(new Font("Tahoma", Font.BOLD, 20));
		cadastro.setBounds(330, 140, 100, 20);
		add(cadastro);
		
		JLabel Nascimento = new JLabel("Digite sua data de nascimento:");
		Nascimento.setBounds(280, 282, 200, 15);
		add(Nascimento);
		
		textNascimento = new JTextField();
		textNascimento.setBounds(280, 307, 210, 20);
		add(textNascimento);
		textNascimento.setColumns(10);
		
		JButton botVoltar = new JButton("Voltar");
		botVoltar.setBounds(10, 11, 89, 23);
		add(botVoltar);
		
		botVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				textLogin.setText("");
				textSenha.setText("");
				textNascimento.setText("");
				loginPane.setVisible(true);
			}
		});
		
		botCadastro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Usuario user = new Usuario();
				String name = textLogin.getText();
				char[] senha = textSenha.getPassword();
				String pass = new String(senha);
				user.setNome(name);
				user.setSenha(pass);
				user.setDataNascimento(textNascimento.getText());
				if( !sistema.criarUsuario(user) ) {
					JOptionPane.showMessageDialog(null, "Usuario ja existe!");
				}
				else if(name.equals("")) {
					JOptionPane.showMessageDialog(null, "Digite um nome de usuario!");
				}
				else if(pass.equals("")) {
					JOptionPane.showMessageDialog(null, "Digite uma senha!");
				}
				else if(textNascimento.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Digite uma data de nascimento!");
				}
				else {
					usuarios.add();
					setVisible(false);
					textLogin.setText("");
					textSenha.setText("");
					textNascimento.setText("");
					loginPane.setVisible(true);
				}
			}
		});
	}
	public void setLoginPane( PaginaLogin pl ) {
		this.loginPane = pl;
	}
	public void setUsuarios(TabelaUsuarios usuarios) {
		this.usuarios = usuarios;
	}
	
}
