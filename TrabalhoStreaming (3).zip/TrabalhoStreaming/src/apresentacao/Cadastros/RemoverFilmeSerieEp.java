package apresentacao.Cadastros;

import javax.swing.JPanel;

import negocio.SistemaStreaming;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import apresentacao.Catalogos.CatalogoEps;
import apresentacao.Catalogos.CatalogoFilme;
import apresentacao.Catalogos.CatalogoSerie;
import apresentacao.Menu.Options;
import apresentacao.Tabelas.TabelaEps;
import apresentacao.Tabelas.TabelaFilmes;
import apresentacao.Tabelas.TabelaLista;
import apresentacao.Tabelas.TabelaSeries;
import dados.Episodio;
import dados.Filme;
import dados.Serie;

import java.awt.Font;
import javax.swing.JRadioButton;
import javax.swing.JTable;

public class RemoverFilmeSerieEp extends JPanel {

	private static final long serialVersionUID = 1L;

	private SistemaStreaming sistema = SistemaStreaming.getInstance();
	private Options opcoesAdmPane;
	private TabelaFilmes filmes;
	private TabelaSeries series;
	private TabelaLista lista;
	private TabelaEps eps;
	private JTable tabelaSeries;
	private JTable tabelaFilmes;
	private JTable tabelaEps;
	private CatalogoFilme catalogoFilmePane;
	private CatalogoSerie catalogoSeriePane;
	private CatalogoEps catalogoEpsPane;
	
	public RemoverFilmeSerieEp() {
		setVisible(false);
		setSize(800,100);
		setLayout(null);
		
		JLabel titleLabel = new JLabel("Remover Filme/Serie/Episodio");
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		titleLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
		titleLabel.setBounds(0, -6, 800, 40);
		add(titleLabel);
		
		JLabel opcRemLabel = new JLabel("Escolha o que deseja remover:");
		opcRemLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		opcRemLabel.setHorizontalAlignment(SwingConstants.CENTER);
		opcRemLabel.setBounds(0, 34, 800, 23);
		add(opcRemLabel);
		
		JRadioButton remFilme = new JRadioButton("Filme");
		remFilme.setBounds(217, 64, 111, 23);
		add(remFilme);
		
		JRadioButton remSerie = new JRadioButton("Serie");
		remSerie.setBounds(330, 64, 111, 23);
		add(remSerie);
		
		JRadioButton remEp = new JRadioButton("Episódio");
		remEp.setBounds(443, 64, 111, 23);
		add(remEp);
		
		ButtonGroup opcRemover = new ButtonGroup();
		opcRemover.add(remEp);
		opcRemover.add(remSerie);
		opcRemover.add(remFilme);
		
		JButton botVoltar = new JButton("Voltar");
		botVoltar.setBounds(10, 11, 89, 23);
		add(botVoltar);
		botVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				opcRemover.clearSelection();
				setVisible(false);
				catalogoFilmePane.setVis(false);
				catalogoSeriePane.setVis(false);
				catalogoEpsPane.setVis(false);
				catalogoFilmePane.changeVisibility();
				catalogoSeriePane.changeVisibility();
				catalogoEpsPane.changeVisibility();
				opcoesAdmPane.setVisible(true);
			}
		});
		
		JButton botRemover = new JButton("Remover");
		botRemover.setBounds(681, 64, 89, 23);
		add(botRemover);
		botRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if( remEp.isSelected() ) {
					int linhaSelecionada = tabelaEps.getSelectedRow();
					Episodio ep = (Episodio)tabelaEps.getModel().getValueAt(linhaSelecionada, -1);
					if( sistema.excluirEp(ep) ) {
						JOptionPane.showMessageDialog(null, "Episodio removido com sucesso!");
						series.atualiza();
						lista.atualiza();
						eps.rmv();
						//nomeText.setText("");
						opcRemover.clearSelection();
						setVisible(false);
						catalogoEpsPane.setVis(false);
						catalogoEpsPane.changeVisibility();
						opcoesAdmPane.setVisible(true);
					}
					else {
						JOptionPane.showMessageDialog(null, "Esse episodio não está cadastrado!");
					}
				}
				else if( remSerie.isSelected() ) {
					int linhaSelecionada = tabelaSeries.getSelectedRow();
	        		Serie serie = (Serie)tabelaSeries.getModel().getValueAt(linhaSelecionada, -1);
					if( sistema.excluirFilmeOuSerie(serie) ) {
						JOptionPane.showMessageDialog(null, "Serie removida com sucesso!");
						series.rmv();
						lista.rmv();
						eps.atualiza();
						//nomeText.setText("");
						opcRemover.clearSelection();
						setVisible(false);
						catalogoSeriePane.setVis(false);
						catalogoSeriePane.changeVisibility();
						opcoesAdmPane.setVisible(true);
					}
					else {
						JOptionPane.showMessageDialog(null, "Serie não está cadastrada!");
					}
				}
				else if( remFilme.isSelected() ) {
					int linhaSelecionada = tabelaFilmes.getSelectedRow();
	        		Filme filme = (Filme)tabelaFilmes.getModel().getValueAt(linhaSelecionada, -1);
					if( sistema.excluirFilmeOuSerie(filme) ) {
						JOptionPane.showMessageDialog(null, "Filme removido com sucesso!");
						filmes.rmv();
						lista.rmv();
						//nomeText.setText("");
						opcRemover.clearSelection();
						setVisible(false);
						catalogoFilmePane.setVis(false);
						catalogoFilmePane.changeVisibility();
						opcoesAdmPane.setVisible(true);
					}
					else {
						JOptionPane.showMessageDialog(null, "Filme não está cadastrado!");
					}
				}
			}
		});
		
		JButton botMostrar = new JButton("Mostrar Lista");
		botMostrar.setBounds(560, 64, 111, 23);
		add(botMostrar);
		botMostrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if( remEp.isSelected() ) {
					catalogoEpsPane.setVis(true);
					catalogoEpsPane.changeVisibility();
					catalogoFilmePane.setVis(false);
					catalogoFilmePane.changeVisibility();
					catalogoSeriePane.setVis(false);
					catalogoSeriePane.changeVisibility();
				}
				else if( remSerie.isSelected() ) {
					catalogoEpsPane.setVis(false);
					catalogoEpsPane.changeVisibility();
					catalogoFilmePane.setVis(false);
					catalogoFilmePane.changeVisibility();
					catalogoSeriePane.setVis(true);
					catalogoSeriePane.changeVisibility();
				}
				else if( remFilme.isSelected() ) {
					catalogoEpsPane.setVis(false);
					catalogoEpsPane.changeVisibility();
					catalogoFilmePane.setVis(true);
					catalogoFilmePane.changeVisibility();
					catalogoSeriePane.setVis(false);
					catalogoSeriePane.changeVisibility();
				}
			}
		});
		
		
	}

	public void setOpcoesAdmPane(Options opcoesAdmPane) {
		this.opcoesAdmPane = opcoesAdmPane;
	}

	public void setFilmes(TabelaFilmes filmes) {
		this.filmes = filmes;
	}

	public void setSeries(TabelaSeries series) {
		this.series = series;
	}

	public void setLista(TabelaLista lista) {
		this.lista = lista;
	}

	public void setCatalogoFilmePane(CatalogoFilme catalogoFilmePane) {
		this.catalogoFilmePane = catalogoFilmePane;
	}

	public void setCatalogoSeriePane(CatalogoSerie catalogoSeriePane) {
		this.catalogoSeriePane = catalogoSeriePane;
	}

	public void setTabelaSeries(JTable tabelaSeries) {
		this.tabelaSeries = tabelaSeries;
	}

	public void setTabelaFilmes(JTable tabelaFilmes) {
		this.tabelaFilmes = tabelaFilmes;
	}

	public void setEps(TabelaEps eps) {
		this.eps = eps;
	}

	public void setTabelaEps(JTable tabelaEps) {
		this.tabelaEps = tabelaEps;
	}

	public void setCatalogoEpsPane(CatalogoEps catalogoEpsPane) {
		this.catalogoEpsPane = catalogoEpsPane;
	}
	
	
}
