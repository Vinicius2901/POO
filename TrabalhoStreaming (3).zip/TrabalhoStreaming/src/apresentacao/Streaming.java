package apresentacao;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import apresentacao.Cadastros.CadastroAtor;
import apresentacao.Cadastros.CadastroEp;
import apresentacao.Cadastros.CadastroFilmeSerie;
import apresentacao.Cadastros.PaginaCadastro;
import apresentacao.Cadastros.PaginaLogin;
import apresentacao.Cadastros.RemoverFilmeSerieEp;
import apresentacao.Catalogos.Catalogo;
import apresentacao.Catalogos.CatalogoEps;
import apresentacao.Catalogos.CatalogoFilme;
import apresentacao.Catalogos.CatalogoSerie;
import apresentacao.Catalogos.Lista;
import apresentacao.Catalogos.ListaUsuarios;
import apresentacao.Menu.Options;
import apresentacao.Tabelas.TabelaEps;
import apresentacao.Tabelas.TabelaFilmes;
import apresentacao.Tabelas.TabelaLista;
import apresentacao.Tabelas.TabelaSeries;
import apresentacao.Tabelas.TabelaUsuarios;

public class Streaming extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane = new JPanel();
	private PaginaLogin loginPane = new PaginaLogin();
	private PaginaCadastro cadastroPane = new PaginaCadastro();
	private Options opcoesAdmPane = new Options();
	private CadastroFilmeSerie cadastroFilmeSeriePane = new CadastroFilmeSerie();
	private CadastroAtor cadastroAtorPane = new CadastroAtor();
	private RemoverFilmeSerieEp remFilmeSerieEpPane = new RemoverFilmeSerieEp();
	private CadastroEp cadastroEpPane = new CadastroEp();
	private Catalogo catalogoPane = new Catalogo();

	public Streaming() {
		setTitle("Sistema Streaming");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setBounds(100,100,800,600);
		setResizable(false);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		loginPane.setCadastroPane(cadastroPane);
		loginPane.setOpcoesAdmPane(opcoesAdmPane);
		opcoesAdmPane.setLocation(90, 55);
		
		opcoesAdmPane.setCadastroAtorPane(cadastroAtorPane);
		opcoesAdmPane.setCadastroFilmeSeriePane(cadastroFilmeSeriePane);
		opcoesAdmPane.setLoginPane(loginPane);
		opcoesAdmPane.setRemFilmeSeriePane(remFilmeSerieEpPane);
		opcoesAdmPane.setCadastroEpPane(cadastroEpPane);
		opcoesAdmPane.setCatalogoPane(catalogoPane);
		catalogoPane.setLocation(90, 42);
		
		CatalogoFilme catalogoFilmePane = new CatalogoFilme();
		CatalogoSerie catalogoSeriePane = new CatalogoSerie();
		CatalogoEps catalogoEpsPane = new CatalogoEps();
		Lista listaPane = new Lista();
		ListaUsuarios listaUsuariosPane = new ListaUsuarios();
		catalogoPane.setOpcoesAdmPane(opcoesAdmPane);
		catalogoPane.setCatalogoFilmePane(catalogoFilmePane);
		catalogoPane.setCatalogoSeriePane(catalogoSeriePane);
		catalogoPane.setListaPane(listaPane);
		
		catalogoFilmePane.setCatalogoPane(catalogoPane);
		JScrollPane scrollPaneFilmes = catalogoFilmePane.getScrollPaneFilmes();
		TabelaFilmes filmes = catalogoFilmePane.getFilmes();
		
		catalogoSeriePane.setCatalogoPane(catalogoPane);
		JScrollPane scrollPaneSeries = catalogoSeriePane.getScrollPaneSeries();
		TabelaSeries series = catalogoSeriePane.getSeries();
		
		listaPane.setCatalogoPane(catalogoPane);
		JScrollPane scrollPaneLista = listaPane.getScrollPaneLista();
		TabelaLista lista = listaPane.getLista();
		loginPane.setListaUsuario(lista);
		
		JScrollPane scrollPaneEps = catalogoEpsPane.getScrollPaneEps();
		TabelaEps eps = catalogoEpsPane.getEps();
		
		listaUsuariosPane.setOpcoesAdmPane(opcoesAdmPane);
		listaUsuariosPane.setLoginPane(loginPane);
		JScrollPane scrollPaneUsuarios = listaUsuariosPane.getScrollPaneUsuarios();
		TabelaUsuarios listaUsuarios = listaUsuariosPane.getUsuarios();
		
		catalogoFilmePane.setLista(lista);
		catalogoSeriePane.setLista(lista);
		
		scrollPaneFilmes.setVisible(false);
		scrollPaneSeries.setVisible(false);
		scrollPaneLista.setVisible(false);
		scrollPaneEps.setVisible(false);
		scrollPaneUsuarios.setVisible(false);
		
		opcoesAdmPane.setListaUsuariosPane(listaUsuariosPane);
		cadastroPane.setUsuarios(listaUsuarios);
		
		cadastroEpPane.setOpcoesAdmPane(opcoesAdmPane);
		cadastroEpPane.setSeries(series);
		cadastroEpPane.setEps(eps);
		cadastroEpPane.setCatalogoSeriePane(catalogoSeriePane);
		cadastroEpPane.setTabelaSeries(catalogoSeriePane.getTabelaSeries());
		
		remFilmeSerieEpPane.setOpcoesAdmPane(opcoesAdmPane);
		remFilmeSerieEpPane.setFilmes(filmes);
		remFilmeSerieEpPane.setSeries(series);
		remFilmeSerieEpPane.setLista(lista);
		remFilmeSerieEpPane.setEps(eps);
		remFilmeSerieEpPane.setCatalogoFilmePane(catalogoFilmePane);
		remFilmeSerieEpPane.setCatalogoSeriePane(catalogoSeriePane);
		remFilmeSerieEpPane.setCatalogoEpsPane(catalogoEpsPane);
		remFilmeSerieEpPane.setTabelaFilmes(catalogoFilmePane.getTabelaFilmes());
		remFilmeSerieEpPane.setTabelaSeries(catalogoSeriePane.getTabelaSeries());
		remFilmeSerieEpPane.setTabelaEps(catalogoEpsPane.getTabelaEps());
		
		cadastroFilmeSeriePane.setCadastroAtorPane(cadastroAtorPane);
		cadastroFilmeSeriePane.setOpcoesAdmPane(opcoesAdmPane);
		cadastroFilmeSeriePane.setFilmes(filmes);
		cadastroFilmeSeriePane.setSeries(series);
		
		cadastroAtorPane.setCadastroFilmeSeriePane(cadastroFilmeSeriePane);
		cadastroAtorPane.setOpcoesAdmPane(opcoesAdmPane);
		
		cadastroPane.setLoginPane(loginPane);
		
		contentPane.add(loginPane);
		contentPane.add(cadastroPane);
		contentPane.add(opcoesAdmPane);
		contentPane.add(cadastroFilmeSeriePane);
		contentPane.add(cadastroAtorPane);
		contentPane.add(remFilmeSerieEpPane);
		contentPane.add(cadastroEpPane);
		contentPane.add(catalogoPane);
		contentPane.add(catalogoFilmePane);
		contentPane.add(catalogoSeriePane);
		contentPane.add(listaPane);
		contentPane.add(catalogoEpsPane);
		contentPane.add(listaUsuariosPane);
		contentPane.add(scrollPaneFilmes);
		contentPane.add(scrollPaneSeries);
		contentPane.add(scrollPaneLista);
		contentPane.add(scrollPaneEps);
		contentPane.add(scrollPaneUsuarios);
	}
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Streaming frame = new Streaming();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
