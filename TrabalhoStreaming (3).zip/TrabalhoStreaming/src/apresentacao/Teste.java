package apresentacao;

import java.util.ArrayList;
import java.util.List;

import dados.Ator;
import dados.Episodio;
import dados.Filme;
import dados.Serie;
import dados.Usuario;
import negocio.SistemaStreaming;
import persistencia.Conexao;
import persistencia.FilmeSerieDAO;

public class Teste {
	private static SistemaStreaming sistema = SistemaStreaming.getInstance();
	private static int id = 0;
	public static void main(String[] args) {
		
		Usuario usuario = new Usuario(2,"vinicius", "123", "29/01/2005");
		
		sistema.criarUsuario(usuario);
		
		sistema.login("admin", "123");
		
//		// Criando novo usuario
//		Usuario usuario = new Usuario();
//		usuario.setId(id);
//		id++;
//		usuario.setNome("Vinicius");
//		usuario.setSenha("4678P%@uO");
//		usuario.setDataNascimento("29/01/2005");
//		sistema.criarUsuario(usuario);
//		
//		// Mostrando usuario
//		System.out.println( sistema.getUsuarios() );
//		
//		// Criando filme
//		Filme filme1 = new Filme();
//		filme1.setId(id);
//		id++;
//		filme1.setAnoDeLancamento( 2001 );
//		filme1.setDuracao( 152 );
//		filme1.setGenero( "Aventura,Familia,Fantasia" );
//		filme1.setTitulo( "Harry Potter e a Pedra Filosofal" );
//		
		
		//Daniel Radcliffe,Rupert Grint,Emma Watson
		//Richard Harris,Maggie Smith,Robbie Coltrane
//		// Criando elenco principal
//		Ator ator1 = new Ator();
//		ator1.setId(id);
//		id++;
//		ator1.setDataNascimento("23/07/1989");
//		ator1.setNome("Daniel Radcliffe");
//		ator1.setSexo("Masculino");
//		
//		Ator ator2 = new Ator();
//		ator2.setId(id);
//		id++;
//		ator2.setDataNascimento("24/08/1988");
//		ator2.setNome("Rupert Grint");
//		ator2.setSexo("Masculino");
//		
//		Ator ator3 = new Ator();
//		ator3.setId(id);
//		id++;
//		ator3.setDataNascimento("25/04/1995");
//		ator3.setNome("Emma Watson");
//		ator3.setSexo("Feminino");
//		
//		
//		List<Ator> elencoP1 = new ArrayList<Ator>();
//		elencoP1.add(ator1);
//		elencoP1.add(ator2);
//		elencoP1.add(ator3);
//		filme1.setElencoP( elencoP1 );
//		
//		// Criando elenco secundario
//		Ator ator4 = new Ator();
//		ator4.setId(id);
//		id++;
//		ator4.setDataNascimento("01/10/1930");
//		ator4.setNome("Richard Harris");
//		ator4.setSexo("Masculino");
//		
//		Ator ator5 = new Ator();
//		ator5.setId(id);
//		id++;
//		ator5.setDataNascimento("28/12/1934");
//		ator5.setNome("Maggie Smith");
//		ator5.setSexo("Feminino");
//		
//		Ator ator6 = new Ator();
//		ator6.setId(id);
//		id++;
//		ator6.setDataNascimento("30/03/1950");
//		ator6.setNome("Robbie Coltrane");
//		ator6.setSexo("Masculino");
//		
//		List<Ator> elencoS1 = new ArrayList<Ator>();
//		elencoS1.add(ator4);
//		elencoS1.add(ator5);
//		elencoS1.add(ator6);
//		
//		filme1.setElencoS(elencoS1);
//		
//		// Adicionando filme ao catálogo
//		sistema.adicionarFilmeOuSerie(filme1);
//		
//		// Mostando filme em específico
//		System.out.println(sistema.buscarFilmeOuSerie(filme1) + "\n");
//		
//		
//		// Criando segundo filme
//		Filme filme2 = new Filme();
//		filme2.setId(id);
//		id++;
//		filme2.setAnoDeLancamento( 2002 );
//		filme2.setDuracao( 158 );
//		filme2.setGenero( "Aventura, Fantasia" );
//		filme2.setTitulo( "Harry Potter e a Camara Secreta" );
//		filme2.setElencoP(elencoP1);
//		filme2.setElencoS(elencoS1);
//		
//		// Adicionando filme ao catálogo
//		sistema.adicionarFilmeOuSerie(filme2);
//		
//		System.out.println(sistema.mostrarCatalogo() + "\n");
//		System.out.println(sistema.buscarFilmeOuSerie(filme1) + "\n");
//		
//		
//		// Criando serie
//		Serie serie1 = new Serie();
//		serie1.setId(id);
//		id++;
//		serie1.setTitulo("Outer Banks");
//		serie1.setGenero("Drama,Aventura,Acao,Misterio,Suspense");
//		serie1.setTemporadas(2);
//		serie1.setAnoDeLancamento( 2020 );
//		
		//Chase Stokes,Madelyn Cline,Madison Bailey,Jonathan Daviss,Rudy Pankow
		//Drew Starkey,Charles Esten,Austin North,Caroline Arapoglou,Cullen Moss
//		//Criando elenco principal
//		Ator ator7 = new Ator( id, "Chase Stokes", "16/09/1992", "Masculino");
//		id++;
//		Ator ator8 = new Ator( id, "Madelyn Cline", "21/12/1997", "Feminino");
//		id++;
//		Ator ator9 = new Ator( id, "Madison Bailey", "29/01/1999", "Feminino");
//		id++;
//		Ator ator10 = new Ator( id, "Jonathan Daviss", "28/02/2000", "Masculino");
//		id++;
//		Ator ator11 = new Ator( id, "Rudy Pankow", "12/08/1998", "Masculino");
//		id++;
//		
//		List<Ator> elencoP2 = new ArrayList<Ator>();
//		elencoP2.add(ator7);
//		elencoP2.add(ator8);
//		elencoP2.add(ator9);
//		elencoP2.add(ator10);
//		elencoP2.add(ator11);
//		serie1.setElencoP(elencoP2);
//		
//		// Criando elenco secundário
//		Ator ator12 = new Ator( id, "Drew Starkey", "04/11/1993", "Masculino");
//		id++;
//		Ator ator13 = new Ator( id, "Charles Esten", "09/09/1965", "Masculino");
//		id++;
//		Ator ator14 = new Ator( id, "Austin North", "30/07/1996", "Masculino");
//		id++;
//		Ator ator15 = new Ator( id, "Caroline Arapoglou", "15/01/1991", "Feminino");
//		id++;
//		Ator ator16 = new Ator( id, "Cullen Moss", "08/07/1975", "Masculino");
//		id++;
//		
//		List<Ator> elencoS2 = new ArrayList<Ator>();
//		elencoS2.add(ator12);
//		elencoS2.add(ator13);
//		elencoS2.add(ator14);
//		elencoS2.add(ator15);
//		elencoS2.add(ator16);
//		
//		serie1.setElencoS(elencoS2);
//		
//		// Adicionando serie ao catálogo
//		sistema.adicionarFilmeOuSerie(serie1);
//		
//		// Criando Episodios:
//		// EP1:
//		Episodio ep1 = new Episodio();
//		ep1.setId(id);
//		id++;
//		ep1.setTitulo("Piloto");
//		ep1.setNumTemp(1);
//		ep1.setDuracao(54);
//		
//		// EP2:
//		Episodio ep2 = new Episodio( id, "O ouro", 2, 51 );
//		id++;
//		
//		// EP3:
//		Episodio ep3 = new Episodio( id, "Bussola da sorte", 1, 47 );
//		id++;
//		
//		// Adicionando eps a serie:
//		sistema.adicionarEp(serie1, ep1);
//		sistema.adicionarEp(serie1, ep2);
//		sistema.adicionarEp(serie1, ep3);
//		
//		// Mostrando catálogo completo:
//		System.out.println(sistema.mostrarCatalogo() + "\n");
//		
//		// Mostrando série em específico:
//		System.out.println(sistema.buscarFilmeOuSerie(serie1) + "\n");
//		
//		// Mostando catálogo de filmes:
//		System.out.println(sistema.buscarFilmes() + "\n");
//		
//		// Mostrando catálogo de séries:
//		System.out.println(sistema.buscarSeries() + "\n");
//		
//		
//		// Criando segundo usuário:
//		Usuario usuario2 = new Usuario( id, "Douglas", "D$45!iTp", "15/09/1973");
//		
//		sistema.criarUsuario(usuario2);
//		
//		// Logando no sistema como o primeiro usuário criado:
//		sistema.login( "Vinicius", "4678P%@uO" );
//		
//		// Adicionando filme na lista:
//		sistema.addListaUsuario(filme1);
//		
//		// Adicionando série na lista:
//		sistema.addListaUsuario(serie1);
//		
//		// Mostrando usuários e suas listas:
//		System.out.println(sistema.getUsuarios() + "\n");
//		
//		// Excluindo ep da série:
//		sistema.excluirEp(ep2);
//		
//		// Mostrando séries:
//		System.out.println(sistema.buscarSeries() + "\n");
//		// Mostrando usuário cuja série da lista teve episódio removido:
//		System.out.println(sistema.buscaUsuario( usuario ) + "\n");
//		
//		// Deslogando do primeiro usuário:
//		sistema.logout();
//		
//		// Logando como segundo usuário:
//		sistema.login("Douglas", "D$45!iTp");
//		
//		// Adicionando filme 2 na lista do segundo usuário
//		sistema.addListaUsuario(filme2);
//		
//		// Mostrando todos os usuários e suas listas:
//		System.out.println(sistema.getUsuarios() + "\n");
//		
//		// Removendo o segundo filme da lista do segundo usuário:
//		sistema.removerListaUsuario(filme2);
//		
//		// Mostrando o usuário com o filme removido da lista:
//		System.out.println( sistema.buscaUsuario(usuario2) + "\n");
//		
//		// Deslogando do segundo usuário:
//		sistema.logout();
//		
//		// Mostrando todos os usuários:
//		System.out.println(sistema.getUsuarios() + "\n");
//		
//		// Removendo filme 1 e série 1 do catálogo:
//		sistema.excluirFilmeOuSerie(filme1);
//		sistema.excluirFilmeOuSerie(serie1);
//		
//		// Deletando segundo usuário:
//		sistema.deletaUsuario(usuario2);
//		
//		// Mostarando catálogo:
//		System.out.println(sistema.mostrarCatalogo() + "\n");
//		// Mostrando usuários e suas listas após ter o filme 1 e a série 1 removidos do catálogo e o usuário 2 excluído:
//		System.out.println(sistema.getUsuarios() + "\n");
//		
//		try {
//			filmeSerieDAO = FilmeSerieDAO.getInstance();
//			System.out.println(filmeSerieDAO.select(0));
//		} catch (Exception e) {
//			System.out.println(e);
//		}
		
		System.out.println(sistema.getLogado());
		
	}
}
