package apresentacao.Catalogos;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import apresentacao.Menu.Options;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class Catalogo extends JPanel {

	private static final long serialVersionUID = 1L;
	private Options opcoesAdmPane;
	private CatalogoFilme catalogoFilmePane;
	private CatalogoSerie catalogoSeriePane;
	private Lista listaPane;

	public Catalogo() {
		setSize(600,510);
		setLayout(null);
		setVisible(false);
		
		JLabel title = new JLabel("Escolha o que deseja:");
		title.setFont(new Font("Tahoma", Font.BOLD, 30));
		title.setHorizontalAlignment(SwingConstants.CENTER);
		title.setBounds(0, 0, 600, 40);
		add(title);
		
		JButton botFilmes = new JButton("Ver filmes");
		botFilmes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				catalogoFilmePane.setVis(true);
				catalogoFilmePane.changeVisibility();
				setVisible(false);
				catalogoFilmePane.setVisible(true);
			}
		});
		botFilmes.setBounds(0, 100, 600, 80);
		add(botFilmes);
		
		JButton botSeries = new JButton("Ver series");
		botSeries.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				catalogoSeriePane.setVis(true);
				catalogoSeriePane.changeVisibility();
				setVisible(false);
				catalogoSeriePane.setVisible(true);
			}
		});
		botSeries.setBounds(0, 230, 600, 80);
		add(botSeries);
		
		JButton botVoltar = new JButton("Voltar");
		botVoltar.setBounds(10, 17, 89, 23);
		add(botVoltar);
		botVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				opcoesAdmPane.setVisible(true);
			}
		});
		
		JButton botLista = new JButton("Ver Minha Lista");
		botLista.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				listaPane.setVis(true);
				listaPane.changeVisibility();
				setVisible(false);
				listaPane.setVisible(true);
			}
		});
		botLista.setBounds(0, 360, 600, 80);
		add(botLista);
	}

	public void setOpcoesAdmPane(Options opcoesAdmPane) {
		this.opcoesAdmPane = opcoesAdmPane;
	}

	public void setCatalogoFilmePane(CatalogoFilme catalogoFilmePane) {
		this.catalogoFilmePane = catalogoFilmePane;
	}

	public void setCatalogoSeriePane(CatalogoSerie catalogoSeriePane) {
		this.catalogoSeriePane = catalogoSeriePane;
	}

	public void setListaPane(Lista listaPane) {
		this.listaPane = listaPane;
	}
	
	

}
