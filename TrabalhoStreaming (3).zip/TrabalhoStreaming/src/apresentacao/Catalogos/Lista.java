package apresentacao.Catalogos;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import apresentacao.Tabelas.TabelaLista;
import dados.Filme;
import negocio.SistemaStreaming;

public class Lista extends JPanel {

	private static final long serialVersionUID = 1L;
	private TabelaLista lista;
	private JTable tabelaLista;
	private JScrollPane scrollPaneLista;
	private Catalogo catalogoPane;
	private SistemaStreaming sistema = SistemaStreaming.getInstance();
	private boolean vis = false;

	public Lista() {
		setVisible(false);
        setSize(800,80);
        lista = new TabelaLista();
        setLayout(null);
        tabelaLista = new JTable(lista);
        tabelaLista.setRowHeight(180);
        //add(tabelaSeries);
        scrollPaneLista = new JScrollPane(tabelaLista);
        scrollPaneLista.setBounds(10, 83, 765, 427);
        add(scrollPaneLista);
        //scrollPaneLista.setVisible(false);
        JButton botVoltar = new JButton("Voltar");
        botVoltar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		setVisible(false);
        		vis = false;
        		catalogoPane.setVisible(true);
        		changeVisibility();
        	}
        });
        botVoltar.setBounds(10, 11, 89, 23);
        add(botVoltar);
        
        /*JButton botAddLista = new JButton("Adicionar à Lista");
        botAddLista.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		int linhaSelecionada = tabelaLista.getSelectedRow();
        		Serie serie = (Serie)tabelaLista.getModel().getValueAt(linhaSelecionada, -1);
        		if( linhaSelecionada >= 0 ) {
        			if( sistema.getLogado().getFilmes().contains(serie) ) {
        				JOptionPane.showMessageDialog(null, "Filme/Série já está adicionada à lista!");
        			}
        			else {
        				sistema.addListaUsuario(serie);
        				JOptionPane.showMessageDialog(null, "Série adicionada à lista com sucesso!");
        			}
        		}
        	}
        });
        botAddLista.setBounds(610, 11, 149, 23);
        add(botAddLista);*/
        
        JButton botRmvLista = new JButton("Remover da lista");
        botRmvLista.setBounds(610, 46, 149, 23);
        add(botRmvLista);
        botRmvLista.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		int linhaSelecionada = tabelaLista.getSelectedRow();
        		Filme filme = (Filme)tabelaLista.getModel().getValueAt(linhaSelecionada, -1);
        		if( linhaSelecionada >= 0 ) {
        			if( sistema.buscaListaUsuario().contains(filme) ) {
        				sistema.removerListaUsuario(filme);
        				lista.rmv();
        				JOptionPane.showMessageDialog(null, "Filme/Série removido da lista com sucesso!");
        			}
        			else {
        				JOptionPane.showMessageDialog(null, "Filme/Série não está na lista!");
        			}
        		}
        	}
        });
	}

	public TabelaLista getLista() {
		return lista;
	}

	public JScrollPane getScrollPaneLista() {
		return scrollPaneLista;
	}
	public void setCatalogoPane(Catalogo catalogoPane) {
		this.catalogoPane = catalogoPane;
	}
	
	public void setVis(boolean vis) {
		this.vis = vis;
	}

	public void changeVisibility() {
		scrollPaneLista.setVisible(vis);
	}
	

}
