package apresentacao.Catalogos;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import apresentacao.Tabelas.TabelaLista;
import apresentacao.Tabelas.TabelaSeries;
import dados.Serie;
import negocio.SistemaStreaming;

public class CatalogoSerie extends JScrollPane {

	private static final long serialVersionUID = 1L;
	private TabelaSeries series;
	private JTable tabelaSeries;
	private JScrollPane scrollPaneSeries;
	private Catalogo catalogoPane;
	private SistemaStreaming sistema = SistemaStreaming.getInstance();
	private TabelaLista lista;
	private boolean vis = false;

	public CatalogoSerie() {
		setVisible(false);
        setSize(800,80);
        series = new TabelaSeries();
        setLayout(null);
        tabelaSeries = new JTable(series);
        tabelaSeries.setRowHeight(180);
        //add(tabelaSeries);
        scrollPaneSeries = new JScrollPane(tabelaSeries);
        scrollPaneSeries.setBounds(10, 103, 765, 427);
        //add(scrollPaneSeries);
        //scrollPaneSeries.setVisible(false);
        JButton botVoltar = new JButton("Voltar");
        botVoltar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		setVisible(false);
        		vis = false;
        		catalogoPane.setVisible(true);
        		changeVisibility();
        	}
        });
        botVoltar.setBounds(10, 11, 89, 23);
        add(botVoltar);
        
        JButton botAddLista = new JButton("Adicionar à Lista");
        botAddLista.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		int linhaSelecionada = tabelaSeries.getSelectedRow();
        		Serie serie = (Serie)tabelaSeries.getModel().getValueAt(linhaSelecionada, -1);
        		if( linhaSelecionada >= 0 ) {
        			if( sistema.getLogado().getFilmes().contains(serie) ) {
        				JOptionPane.showMessageDialog(null, "Série já está adicionada à lista!");
        			}
        			else {
        				sistema.addListaUsuario(serie);
        				lista.add();
        				JOptionPane.showMessageDialog(null, "Série adicionada à lista com sucesso!");
        			}
        		}
        	}
        });
        botAddLista.setBounds(610, 11, 149, 23);
        add(botAddLista);
        
        JButton botRmvLista = new JButton("Remover da lista");
        botRmvLista.setBounds(610, 46, 149, 23);
        add(botRmvLista);
        botRmvLista.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		int linhaSelecionada = tabelaSeries.getSelectedRow();
        		Serie serie = (Serie)tabelaSeries.getModel().getValueAt(linhaSelecionada, -1);
        		if( linhaSelecionada >= 0 ) {
        			if( sistema.getLogado().getFilmes().contains(serie) ) {
        				sistema.removerListaUsuario(serie);
        				lista.rmv();
        				JOptionPane.showMessageDialog(null, "Série removida da lista com sucesso!");
        			}
        			else {
        				JOptionPane.showMessageDialog(null, "Série não está na lista!");
        			}
        		}
        	}
        });
	}

	public TabelaSeries getSeries() {
		return series;
	}

	public JScrollPane getScrollPaneSeries() {
		return scrollPaneSeries;
	}
	public void setCatalogoPane(Catalogo catalogoPane) {
		this.catalogoPane = catalogoPane;
	}
	
	public void setVis(boolean vis) {
		this.vis = vis;
	}
	public void setLista( TabelaLista l ) {
		this.lista = l;
	}

	public JTable getTabelaSeries() {
		return tabelaSeries;
	}

	public void changeVisibility() {
		scrollPaneSeries.setVisible(vis);
	}
	

}
