package apresentacao.Catalogos;


import javax.swing.JScrollPane;
import javax.swing.JTable;

import apresentacao.Tabelas.TabelaEps;

public class CatalogoEps extends JScrollPane {

	private static final long serialVersionUID = 1L;
	private TabelaEps eps;
	private JTable tabelaEps;
	private JScrollPane scrollPaneEps;
	private boolean vis = false;

	public CatalogoEps() {
		setVisible(false);
        setSize(800,80);
        eps = new TabelaEps();
        setLayout(null);
        tabelaEps = new JTable(eps);
        tabelaEps.setRowHeight(120);
        //add(tabelaSeries);
        scrollPaneEps = new JScrollPane(tabelaEps);
        scrollPaneEps.setBounds(10, 103, 765, 427);
        //add(scrollPaneEps);
	}

	public TabelaEps getEps() {
		return eps;
	}

	public JScrollPane getScrollPaneEps() {
		return scrollPaneEps;
	}
	
	public void setVis(boolean vis) {
		this.vis = vis;
	}

	public JTable getTabelaEps() {
		return tabelaEps;
	}

	public void changeVisibility() {
		scrollPaneEps.setVisible(vis);
	}
	

}
