package apresentacao.Catalogos;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import apresentacao.Cadastros.PaginaLogin;
import apresentacao.Menu.Options;
import apresentacao.Tabelas.TabelaUsuarios;
import dados.Usuario;
import negocio.SistemaStreaming;

public class ListaUsuarios extends JScrollPane {

	private static final long serialVersionUID = 1L;
	private TabelaUsuarios usuarios;
	private JTable tabelaUsuarios;
	private JScrollPane scrollPaneUsuarios;
	private Options opcoesAdmPane;
	private SistemaStreaming sistema = SistemaStreaming.getInstance();
	private PaginaLogin loginPane;
	private boolean vis = false;

	public ListaUsuarios() {
		setVisible(false);
        setSize(800,80);
        usuarios = new TabelaUsuarios();
        setLayout(null);
        tabelaUsuarios = new JTable(usuarios);
        //add(tabelaSeries);
        scrollPaneUsuarios = new JScrollPane(tabelaUsuarios);
        scrollPaneUsuarios.setBounds(10, 103, 765, 427);
        //add(scrollPaneUsuarios);
        //scrollPaneSeries.setVisible(false);
        JButton botVoltar = new JButton("Voltar");
        botVoltar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		setVisible(false);
        		vis = false;
        		opcoesAdmPane.setVisible(true);
        		changeVisibility();
        	}
        });
        botVoltar.setBounds(10, 11, 89, 23);
        add(botVoltar);
        
        JButton botRmvLista = new JButton("Remover Usuario");
        botRmvLista.setBounds(610, 46, 149, 23);
        add(botRmvLista);
        botRmvLista.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		int linhaSelecionada = tabelaUsuarios.getSelectedRow();
        		Usuario usuario = (Usuario)tabelaUsuarios.getModel().getValueAt(linhaSelecionada, -1);
        		if( linhaSelecionada >= 0 ) {
        			if( sistema.getUsuarios().contains(usuario) ) {
        				if( !sistema.getLogado().equals(usuario) ) {
        					sistema.deletaUsuario(usuario);
        					usuarios.rmv();
        					JOptionPane.showMessageDialog(null, "Usuario deletado com sucesso!");
        				}
        				else {
        					sistema.logout();
        					sistema.deletaUsuario(usuario);
        					usuarios.rmv();
        					JOptionPane.showMessageDialog(null, "Você se deletou com sucesso!");
        					setVisible(false);
        					setVis(false);
        					changeVisibility();
        					loginPane.setVisible(true);
        					
        				}
        			}
        			else {
        				JOptionPane.showMessageDialog(null, "Usuário não existe!");
        			}
        		}
        	}
        });
	}

	public TabelaUsuarios getUsuarios() {
		return usuarios;
	}

	public JScrollPane getScrollPaneUsuarios() {
		return scrollPaneUsuarios;
	}
	public void setOpcoesAdmPane(Options opcoesAdmPane) {
		this.opcoesAdmPane = opcoesAdmPane;
	}
	
	public void setVis(boolean vis) {
		this.vis = vis;
	}
	public void setListaUsuarios( TabelaUsuarios usuarios ) {
		this.usuarios = usuarios;
	}

	public JTable getTabelaSeries() {
		return tabelaUsuarios;
	}

	public void changeVisibility() {
		scrollPaneUsuarios.setVisible(vis);
	}

	public void setLoginPane(PaginaLogin loginPane) {
		this.loginPane = loginPane;
	}
	

}
