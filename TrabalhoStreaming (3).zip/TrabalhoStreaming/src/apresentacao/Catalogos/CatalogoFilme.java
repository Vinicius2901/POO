package apresentacao.Catalogos;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import apresentacao.Tabelas.TabelaFilmes;
import apresentacao.Tabelas.TabelaLista;
import dados.Filme;
import negocio.SistemaStreaming;

import javax.swing.JButton;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CatalogoFilme extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTable tabelaFilmes;
	private TabelaFilmes filmes;
	private JScrollPane scrollPaneFilmes;
	private Catalogo catalogoPane;
	private TabelaLista lista;
	private boolean vis = false;
	private SistemaStreaming sistema = SistemaStreaming.getInstance();

	public CatalogoFilme() {
		setVisible(false);
        setSize(800,80);
        filmes = new TabelaFilmes();
        setLayout(null);
        tabelaFilmes = new JTable(filmes);
        tabelaFilmes.setRowHeight(180);
        scrollPaneFilmes = new JScrollPane(tabelaFilmes);
        scrollPaneFilmes.setBounds(10, 103, 765, 427);
        //add(scrollPaneFilmes);
        
        JButton botVoltar = new JButton("Voltar");
        botVoltar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		setVisible(false);
        		vis = false;
        		catalogoPane.setVisible(true);
        		changeVisibility();
        	}
        });
        botVoltar.setBounds(10, 11, 89, 23);
        add(botVoltar);
        
        JButton botAddLista = new JButton("Adicionar à Lista");
        botAddLista.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		int linhaSelecionada = tabelaFilmes.getSelectedRow();
        		Filme filme = (Filme)tabelaFilmes.getModel().getValueAt(linhaSelecionada, -1);
        		if( linhaSelecionada >= 0 ) {
        			if( sistema.getLogado().getFilmes().contains(filme) ) {
        				JOptionPane.showMessageDialog(null, "Filme já está adicionado à lista!");
        			}
        			else {
        				sistema.addListaUsuario(filme);
        				lista.add();
        				JOptionPane.showMessageDialog(null, "Filme adicionado à lista com sucesso!");
        			}
        		}
        	}
        });
        botAddLista.setBounds(610, 11, 149, 23);
        add(botAddLista);
        
        JButton botRmvLista = new JButton("Remover da lista");
        botRmvLista.setBounds(610, 46, 149, 23);
        add(botRmvLista);
        botRmvLista.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		int linhaSelecionada = tabelaFilmes.getSelectedRow();
        		Filme filme = (Filme)tabelaFilmes.getModel().getValueAt(linhaSelecionada, -1);
        		if( linhaSelecionada >= 0 ) {
        			if( sistema.getLogado().getFilmes().contains(filme) ) {
        				sistema.removerListaUsuario(filme);
        				lista.rmv();
        				JOptionPane.showMessageDialog(null, "Filme removido da lista com sucesso!");
        			}
        			else {
        				JOptionPane.showMessageDialog(null, "Filme não está na lista!");
        			}
        		}
        	}
        });
	}

	public JTable getTabelaFilmes() {
		return tabelaFilmes;
	}

	public TabelaFilmes getFilmes() {
		return filmes;
	}

	public JScrollPane getScrollPaneFilmes() {
		return scrollPaneFilmes;
	}

	public void setCatalogoPane(Catalogo catalogoPane) {
		this.catalogoPane = catalogoPane;
	}
	
	public void setVis(boolean vis) {
		this.vis = vis;
	}
	public void setLista( TabelaLista l ) {
		this.lista = l;
	}
	

	public void changeVisibility() {
		scrollPaneFilmes.setVisible(vis);
	}
}
