package apresentacao.Tabelas;


import javax.swing.ImageIcon;
import javax.swing.table.AbstractTableModel;

import dados.Serie;
import negocio.SistemaStreaming;

public class TabelaSeries extends AbstractTableModel {

	private static final long serialVersionUID = 1L;
	private String[] colunas = { "Cartaz", "ID", "Titulo", "Gênero", "N. temporadas", "N. episódios",
			"Duracao", "Ano de Lançamento", "Elenco Principal", "Elenco Secundario" };
	private SistemaStreaming sistema = SistemaStreaming.getInstance();
	private final int COL_CARTAZ = 0;
	private final int COL_ID = 1;
	private final int COL_TITULO = 2;
	private final int COL_GENERO = 3;
	private final int COL_TEMP = 4;
	private final int COL_NEP = 5;
	private final int COL_DURACAO = 6;
	private final int COL_ANO = 7;
	private final int COL_EP = 8;
	private final int COL_ES = 9;
	
	public String getColumnName( int column ) {
		return colunas[column];
	}
	public int getColumnCount() {
		return colunas.length;
	}
	public int getRowCount() {
		return sistema.buscarSeries().size();
	}
	@Override
    public Class getColumnClass(int c) {
        return getValueAt(0, c).getClass();
    }
	public Object getValueAt( int rowIndex, int columnIndex ) {
		if( !sistema.buscarSeries().isEmpty() ) {
			Serie serie = sistema.buscarSeries().get(rowIndex);
			switch(columnIndex) {
			case -1:
				return serie;
			case COL_CARTAZ:
				return new ImageIcon(serie.getCartaz());
			case COL_ID:
				return serie.getId();
			case COL_TITULO:
				return serie.getTitulo();
			case COL_GENERO:
				return serie.getGenero();
			case COL_TEMP:
				return serie.getTemporadas();
			case COL_NEP:
				return serie.getEpisodios().size();
			case COL_DURACAO:
				return serie.getDuracao();
			case COL_ANO:
				return serie.getAnoDeLancamento();
			case COL_EP:
				return serie.getElencoP();
			case COL_ES:
				return serie.getElencoS();
			}
		}
		else {
			return "-";
		}
		return null;
	}
	public void add() {
		fireTableDataChanged();
		fireTableRowsInserted(sistema.buscarSeries().size()-1, sistema.buscarSeries().size()-1);
	}
	public void rmv() {
		fireTableDataChanged();
		fireTableRowsDeleted(sistema.buscarSeries().size()-1, sistema.buscarSeries().size()-1);
	}
	public void atualiza() {
		fireTableDataChanged();
	}
}
