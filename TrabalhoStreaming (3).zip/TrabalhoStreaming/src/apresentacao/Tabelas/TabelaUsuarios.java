package apresentacao.Tabelas;


import javax.swing.table.AbstractTableModel;

import dados.Usuario;
import negocio.SistemaStreaming;

public class TabelaUsuarios extends AbstractTableModel {

	private static final long serialVersionUID = 1L;
	private String[] colunas = { "ID", "Nome", "Senha", "Nascimento", "Lista" };
	private SistemaStreaming sistema = SistemaStreaming.getInstance();
	private final int COL_ID = 0;
	private final int COL_NOME = 1;
	private final int COL_SENHA = 2;
	private final int COL_NASC = 3;
	private final int COL_LISTA = 4;
	
	public String getColumnName( int column ) {
		return colunas[column];
	}
	public int getColumnCount() {
		return colunas.length;
	}
	public int getRowCount() {
		return sistema.getUsuarios().size();
	}
	public Object getValueAt( int rowIndex, int columnIndex ) {
		if( !sistema.getUsuarios().isEmpty() ) {
			Usuario usuario = sistema.getUsuarios().get(rowIndex);
			switch(columnIndex) {
			case -1:
				return usuario;
			case COL_ID:
				return usuario.getId();
			case COL_NOME:
				return usuario.getLogin();
			case COL_SENHA:
				return usuario.getSenha();
			case COL_NASC:
				return usuario.getDataNascimento();
			case COL_LISTA:
				return usuario.getFilmes();
			}
		}
		else {
			return "-";
		}
		return null;
	}
	public void add() {
		fireTableDataChanged();
		fireTableRowsInserted(sistema.getUsuarios().size()-1, sistema.getUsuarios().size()-1);
	}
	public void rmv() {
		fireTableDataChanged();
		fireTableRowsDeleted(sistema.getUsuarios().size()-1, sistema.getUsuarios().size()-1);
	}
	public void atualiza() {
		fireTableDataChanged();
	}
}
