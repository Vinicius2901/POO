package apresentacao.Tabelas;


import javax.swing.ImageIcon;
import javax.swing.table.AbstractTableModel;

import dados.Filme;
import negocio.SistemaStreaming;

public class TabelaFilmes extends AbstractTableModel {

	private static final long serialVersionUID = 1L;
	private String[] colunas = { "Cartaz", "ID", "Titulo", "Gênero", "Duracao", "Ano de Lançamento",
			"Elenco Principal", "Elenco Secundario" };
	private SistemaStreaming sistema = SistemaStreaming.getInstance();
	private final int COL_CARTAZ = 0;
	private final int COL_ID = 1;
	private final int COL_TITULO = 2;
	private final int COL_GENERO = 3;
	private final int COL_DURACAO = 4;
	private final int COL_ANO = 5;
	private final int COL_EP = 6;
	private final int COL_ES = 7;
	
	public String getColumnName( int column ) {
		return colunas[column];
	}
	public int getColumnCount() {
		return colunas.length;
	}
	public int getRowCount() {
		return sistema.buscarFilmes().size();
	}
	
	@Override
    public Class getColumnClass(int c) {
        return getValueAt(0, c).getClass();
    }
	public Object getValueAt( int rowIndex, int columnIndex ) {
		if( !sistema.buscarFilmes().isEmpty() ) {
			Filme filme = sistema.buscarFilmes().get(rowIndex);
			
			switch(columnIndex) {
			case -1:
				return filme;
			case COL_CARTAZ:
				return new ImageIcon(filme.getCartaz());
			case COL_ID:
				return filme.getId();
			case COL_TITULO:
				return filme.getTitulo();
			case COL_GENERO:
				return filme.getGenero();
			case COL_DURACAO:
				return filme.getDuracao();
			case COL_ANO:
				return filme.getAnoDeLancamento();
			case COL_EP:
				return filme.getElencoP();
			case COL_ES:
				return filme.getElencoS();
			}
		}
		else {
			return "-";
		}
		return null;
	}
	public void add() {
		fireTableDataChanged();
		fireTableRowsInserted(sistema.buscarFilmes().size()-1, sistema.buscarFilmes().size()-1);
	}
	public void rmv() {
		fireTableDataChanged();
		fireTableRowsDeleted(sistema.buscarFilmes().size()-1, sistema.buscarFilmes().size()-1);
	}
}
