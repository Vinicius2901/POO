package apresentacao.Tabelas;


import javax.swing.table.AbstractTableModel;

import dados.Episodio;
import negocio.SistemaStreaming;

public class TabelaEps extends AbstractTableModel {

	private static final long serialVersionUID = 1L;
	private String[] colunas = { "ID", "Titulo", "N. Temp", "Duracao" };
	private SistemaStreaming sistema = SistemaStreaming.getInstance();
	private final int COL_ID = 0;
	private final int COL_TITULO = 1;
	//private final int COL_GENERO = 2;
	private final int COL_TEMP = 2;
	//private final int COL_NEP = 4;
	private final int COL_DURACAO = 3;
	//private final int COL_ANO = 6;
	//private final int COL_EP = 7;
	//private final int COL_ES = 8;
	
	public String getColumnName( int column ) {
		return colunas[column];
	}
	public int getColumnCount() {
		return colunas.length;
	}
	public int getRowCount() {
		return sistema.getEps().size();
	}
	public Object getValueAt( int rowIndex, int columnIndex ) {
		if( !sistema.buscarSeries().isEmpty() ) {
			Episodio episodio = sistema.getEps().get(rowIndex);
			switch(columnIndex) {
			case -1:
				return episodio;
			case COL_ID:
				return episodio.getId();
			case COL_TITULO:
				return episodio.getTitulo();
			//case COL_GENERO:
				//return episodio.getGenero();
			case COL_TEMP:
				return episodio.getNumTemp();
			//case COL_NEP:
				//return serie.getEpisodios().size();
			case COL_DURACAO:
				return episodio.getDuracao();
			/*case COL_ANO:
				return serie.getAnoDeLancamento();
			case COL_EP:
				return serie.getElencoP();
			case COL_ES:
				return serie.getElencoS();*/
			}
		}
		else {
			return "-";
		}
		return null;
	}
	public void add() {
		fireTableDataChanged();
		fireTableRowsInserted(sistema.getEps().size()-1, sistema.getEps().size()-1);
	}
	public void rmv() {
		fireTableDataChanged();
		fireTableRowsDeleted(sistema.getEps().size()-1, sistema.getEps().size()-1);
	}
	public void atualiza() {
		fireTableDataChanged();
	}
}
