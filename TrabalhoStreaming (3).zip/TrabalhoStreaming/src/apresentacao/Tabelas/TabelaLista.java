package apresentacao.Tabelas;


import javax.swing.ImageIcon;
import javax.swing.table.AbstractTableModel;

import dados.Filme;
import dados.Serie;
import negocio.SistemaStreaming;

public class TabelaLista extends AbstractTableModel {

	private static final long serialVersionUID = 1L;
	private String[] colunas = { "Cartaz", "ID", "Titulo", "Gênero", "N. temporadas", "N. episódios",
			"Duracao", "Ano de Lançamento", "Elenco Principal", "Elenco Secundario" };
	private SistemaStreaming sistema = SistemaStreaming.getInstance();
	private final int COL_CARTAZ = 0;
	private final int COL_ID = 1;
	private final int COL_TITULO = 2;
	private final int COL_GENERO = 3;
	private final int COL_TEMP = 4;
	private final int COL_NEP = 5;
	private final int COL_DURACAO = 6;
	private final int COL_ANO = 7;
	private final int COL_EP = 8;
	private final int COL_ES = 9;
	
	public String getColumnName( int column ) {
		return colunas[column];
	}
	public int getColumnCount() {
		return colunas.length;
	}
	public int getRowCount() {
		if( sistema.getLogado() != null ) {
			return sistema.buscaListaUsuario().size();
		}
		return 0;
	}
	public Class getColumnClass(int c) {
        return getValueAt(0, c).getClass();
    }
	public Object getValueAt( int rowIndex, int columnIndex ) {
		if( !sistema.buscaListaUsuario().isEmpty() ) {
			Filme filme = sistema.buscaListaUsuario().get(rowIndex);
			if( filme instanceof Serie ) {
				Serie serie = (Serie) filme;
				switch(columnIndex) {
				case -1:
					return serie;
				case COL_CARTAZ:
					return new ImageIcon(serie.getCartaz());
				case COL_ID:
					return serie.getId();
				case COL_TITULO:
					return serie.getTitulo();
				case COL_GENERO:
					return serie.getGenero();
				case COL_TEMP:
					return serie.getTemporadas();
				case COL_NEP:
					return serie.getEpisodios().size();
				case COL_DURACAO:
					return serie.getDuracao();
				case COL_ANO:
					return serie.getAnoDeLancamento();
				case COL_EP:
					return serie.getElencoP();
				case COL_ES:
					return serie.getElencoS();
				}
			}
			else {
				switch(columnIndex) {
				case -1:
					return filme;
				case COL_CARTAZ:
					return new ImageIcon(filme.getCartaz());
				case COL_ID:
					return filme.getId();
				case COL_TITULO:
					return filme.getTitulo();
				case COL_GENERO:
					return filme.getGenero();
				case COL_DURACAO:
					return filme.getDuracao();
				case COL_ANO:
					return filme.getAnoDeLancamento();
				case COL_EP:
					return filme.getElencoP();
				case COL_ES:
					return filme.getElencoS();
				default:
					return "-";
				}
			}
		}
		else {
			return "-";
		}
		return null;
	}
	public void add() {
		fireTableDataChanged();
		fireTableRowsInserted(sistema.buscaListaUsuario().size()-1, sistema.buscaListaUsuario().size()-1);
	}
	public void rmv() {
		fireTableDataChanged();
		fireTableRowsDeleted(sistema.buscaListaUsuario().size()-1, sistema.buscaListaUsuario().size()-1);
	}
	public void atualiza() {
		fireTableDataChanged();
	}
}
