package persistencia;

import java.awt.Image;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import javax.imageio.ImageIO;

import dados.Ator;
import dados.Episodio;
import dados.Filme;
import dados.Serie;
import exceptions.DeleteException;
import exceptions.InsertException;
import exceptions.SelectException;
import exceptions.UpdateException;

public class FilmeSerieDAO {
	private static FilmeSerieDAO instance = null;
	private static ElencoPDAO elencoPDAO;
	private static ElencoSDAO elencoSDAO;
	private static EpisodioDAO episodioDAO;
	private static ListaUsuarioDAO listaUsuarioDAO;
	
	private PreparedStatement selectNewId;
	private PreparedStatement select;
	private PreparedStatement insert;
	private PreparedStatement selectAll;
	private PreparedStatement delete;
	private PreparedStatement update;
	
	public static FilmeSerieDAO getInstance() throws ClassNotFoundException, SQLException, SelectException {
		if( instance == null ) {
			instance = new FilmeSerieDAO();
		}
		return instance;
	}
	
	private FilmeSerieDAO() throws ClassNotFoundException, SQLException, SelectException {
		listaUsuarioDAO = ListaUsuarioDAO.getInstance();
		episodioDAO 	= EpisodioDAO.getInstance();
		elencoPDAO  	= ElencoPDAO.getInstance();
		elencoSDAO  	= ElencoSDAO.getInstance();
		Connection conexao = Conexao.getConexao();
		selectNewId 	= conexao.prepareStatement("select nextval('filme_serie_id')");
		insert      	= conexao.prepareStatement("insert into filme_serie values (?,?,?,?,?,?,?,?)");
		select      	= conexao.prepareStatement("select * from filme_serie where filme_serie_id = ?");
		selectAll   	= conexao.prepareStatement("select * from filme_serie");
		update      	= conexao.prepareStatement("update filme_serie set titulo = ?, genero = ?,"
			    		+ " temporadas = ?, duracao = ?, ano_lancamento = ? where filme_serie_id = ?");
		delete = conexao.prepareStatement("delete from filme_serie where filme_serie_id = ?");
	}
	
	private int selectNewId() throws SelectException {
		try {
			ResultSet rs = selectNewId.executeQuery();
			if( rs.next() ) {
				return rs.getInt(1);
			}
		} catch( SQLException e ) {
			throw new SelectException("Erro ao buscar novo id da tabela filme");
		}
		return 0;
	}
	
	public void insert( Filme filme ) throws InsertException, SelectException {
		try {
			filme.setId(selectNewId());
			insert.setInt(1, filme.getId());
			insert.setString(2, filme.getTitulo());
			insert.setString(3, filme.getGenero());
			if( !(filme instanceof Serie) ) {
				insert.setString(4, "-");
			} else {
				Serie serie = (Serie) filme;
				insert.setString(4, Integer.toString(serie.getTemporadas()));
			}
			insert.setInt(5, filme.getDuracao());
			insert.setInt(6, filme.getAnoDeLancamento());
			try {
				FileInputStream fis = new FileInputStream(filme.getFoto());
				insert.setString(7, filme.getFoto().getName());
				insert.setBinaryStream(8, fis, filme.getFoto().length());
			} catch (FileNotFoundException e) {
				System.out.println(e);
			}
			
			insert.executeUpdate();
			for( Ator a : filme.getElencoP()) {
				elencoPDAO.insert(a, filme);
			}
			for( Ator a : filme.getElencoS()) {
				elencoSDAO.insert(a, filme);
			}
			
		} catch( SQLException e ) {
			throw new InsertException("Erro ao inserir filme");
		}
	}
	
	public Filme select( int filme ) throws SelectException, ClassNotFoundException {
		try {
			select.setInt(1, filme);
			ResultSet rs = select.executeQuery();
			if( rs.next() ) {
				int id = rs.getInt(1);
				String titulo = rs.getString(2);
				String genero = rs.getString(3);
				String numTemp = rs.getString(4);
				int duracao = rs.getInt(5);
				int ano_lancamento = rs.getInt(6);
				byte[] cartazBytes = rs.getBytes(8);
				try {
					Image cartaz = ImageIO.read( new ByteArrayInputStream(cartazBytes));
					if( numTemp.equals("-") ) {
						Filme filme1 = new Filme( id, titulo, genero, duracao, ano_lancamento, cartaz );
						List<Ator> elencoP = elencoPDAO.selectAll(filme1.getId());
						List<Ator> elencoS = elencoSDAO.selectAll(filme1.getId());
						filme1.setElencoP(elencoP);
						filme1.setElencoS(elencoS);
						return filme1;
					}
					else {
						int temp = Integer.parseInt(numTemp);
						Serie serie1 = new Serie( id, titulo, genero, temp, duracao, ano_lancamento, cartaz );
						List<Ator> elencoP = elencoPDAO.selectAll(serie1.getId());
						List<Ator> elencoS = elencoSDAO.selectAll(serie1.getId());
						List<Episodio> eps = episodioDAO.selectAll(serie1);
						for( Episodio ep : eps ) {
							serie1.cadastrarEp(ep);
						}
						serie1.setElencoP(elencoP);
						serie1.setElencoS(elencoS);
						return serie1;
					}
				} catch (IOException e) {
					System.out.println(e);
				}
			}
		} catch( SQLException e ) {
			throw new SelectException("Erro ao buscar filme");
		}
		return null;
	}
	
	public List<Filme> selectAll() throws SelectException, ClassNotFoundException {
		List<Filme> filmes = new LinkedList<>();
		try {
			ResultSet rs = selectAll.executeQuery();
			while( rs.next() ) {
				int id = rs.getInt(1);
				String titulo = rs.getString(2);
				String genero = rs.getString(3);
				String numTemp = rs.getString(4);
				int duracao = rs.getInt(5);
				int anoLancamento = rs.getInt(6);
				File file = new File(rs.getString(7));
				byte[] cartazBytes = rs.getBytes(8);
				try {
					Image cartaz = ImageIO.read( new ByteArrayInputStream(cartazBytes));
					if( numTemp.equals("-") ) {
						Filme filme1 = new Filme( id, titulo, genero, duracao, anoLancamento, cartaz );
						List<Ator> elencoP = elencoPDAO.selectAll(filme1.getId());
						List<Ator> elencoS = elencoSDAO.selectAll(filme1.getId());
						filme1.setElencoP(elencoP);
						filme1.setElencoS(elencoS);
						filmes.add(filme1);
					}
					else {
						int temp = Integer.parseInt(numTemp);
						Serie serie1 = new Serie( id, titulo, genero, temp, duracao, anoLancamento, cartaz );
						List<Ator> elencoP = elencoPDAO.selectAll(serie1.getId());
						List<Ator> elencoS = elencoSDAO.selectAll(serie1.getId());
						List<Episodio> eps = episodioDAO.selectAll(serie1);
						for( Episodio ep : eps ) {
							serie1.cadastrarEp(ep);
						}
						serie1.setElencoP(elencoP);
						serie1.setElencoS(elencoS);
						filmes.add(serie1);
					}
				} catch (IOException e) {
					System.out.println(e);
				}
			}
		} catch (SQLException e) {
			throw new SelectException("Erro ao buscar filme");
		}
		return filmes;
	}
	
	public void update(Filme filme) throws UpdateException {
		try {
			update.setString(1, filme.getTitulo());
			update.setString(2, filme.getGenero());
			if(!(filme instanceof Serie)) {
				update.setString(3, "-");
			}
			else {
				Serie serie = (Serie) filme;
				update.setString(3, Integer.toString(serie.getTemporadas()));
			}
			update.setInt(4, filme.getDuracao());
			update.setInt(5, filme.getAnoDeLancamento());
//			try {
//				FileInputStream fis = new FileInputStream(filme.getFoto());
//				insert.setString(6, filme.getFoto().getName());
//				insert.setBinaryStream(7, fis, filme.getFoto().length());
//			} catch (FileNotFoundException e) {
//				System.out.println(e);
//			}
//			
			update.setInt(6, filme.getId());
		} catch( SQLException e ) {
			throw new UpdateException("Falha ao atualizar filme/serie");
		}
	}
	
	public void delete( Filme filme ) throws DeleteException, ClassNotFoundException {
		try {
			elencoPDAO.delete(filme);
			elencoSDAO.delete(filme);
			listaUsuarioDAO.delete(filme);
			if( filme instanceof Serie ) {
				try {
					Serie serie = (Serie) filme;
					List<Episodio> epsSerie = episodioDAO.selectAll(serie);
					for( Episodio ep : epsSerie ) {
						ep.setSerie(null);
						try {
							episodioDAO.delete(ep);
						} catch (DeleteException e) {
							System.out.println(e.getMessage());
						}
						
					}
				} catch( SelectException e ) {
					System.out.println(e.getMessage());
				}
				
			}
			delete.setInt(1, filme.getId());
			delete.executeUpdate();
		} catch( SQLException e ) {
			throw new DeleteException("Erro ao deletar filme");
		}
	}
	
}
