package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import dados.Usuario;
import exceptions.DeleteException;
import exceptions.InsertException;
import exceptions.SelectException;
import exceptions.UpdateException;

public class UsuarioDAO {
	private static UsuarioDAO instance = null;
	private static ListaUsuarioDAO listaUsuarioDAO;
	
	private PreparedStatement selectNewId;
	private PreparedStatement select;
	private PreparedStatement selectConta;
	private PreparedStatement selectId;
	private PreparedStatement selectAll;
	private PreparedStatement insert;
	private PreparedStatement delete;
	private PreparedStatement update;
	
	public static UsuarioDAO getInstance() throws ClassNotFoundException, SQLException, SelectException {
		if( instance == null ) {
			instance = new UsuarioDAO();
		}
		return instance;
	}
	
	private UsuarioDAO() throws ClassNotFoundException, SQLException, SelectException {
		listaUsuarioDAO = ListaUsuarioDAO.getInstance();
		Connection conexao = Conexao.getConexao();
		selectNewId = conexao.prepareStatement("select nextval('usuario_id')");
		insert = conexao.prepareStatement("insert into usuario values (?,?,?,?)");
		select = conexao.prepareStatement("select * from usuario where login = ?");
		selectConta = conexao.prepareStatement("select * from usuario where login = ?");
		selectId = conexao.prepareStatement("select * from usuario where usuario_id = ?");
		selectAll = conexao.prepareStatement("select * from usuario");
		update = conexao.prepareStatement("update usuario set login = ?, senha = ?, data_nascimento = ? where id_pessoa = ?");
		delete = conexao.prepareStatement("delete from usuario where usuario_id = ?");
	}
	
	private int selectNewId() throws SelectException {
		try {
			ResultSet rs = selectNewId.executeQuery();
			if( rs.next() ) {
				return rs.getInt(1);
			}
		} catch( SQLException e ) {
			throw new SelectException("Erro ao buscar novo id da tabela usuario");
		}
		return 0;
	}
	
	public void insert( Usuario usuario ) throws InsertException, SelectException {
		try {
			insert.setInt(1, selectNewId());
			insert.setString(2, usuario.getLogin());
			insert.setString(3, usuario.getSenha());
			insert.setString(4, usuario.getDataNascimento());
			insert.executeUpdate();
		} catch( SQLException e ) {
			throw new InsertException("Erro ao inserir usuario");
		}
	}
	
	public Usuario select( String login, String senha ) throws SelectException {
		try {
			select.setString(1, login);
			ResultSet rs = select.executeQuery();
			if( rs.next() ) {
				int id = rs.getInt(1);
				if( !senha.equals(rs.getString(3))) {
					return null;
				}
				String dataNascimento = rs.getString(4);
				return new Usuario( id, login, senha, dataNascimento );
			}
		} catch( SQLException e ) {
			throw new SelectException("Erro ao buscar Usuario");
		}
		return null;
	}
	
	public Usuario selectConta( String login, String senha ) throws SelectException {
		try {
			selectConta.setString(1, login);
			ResultSet rs = selectConta.executeQuery();
			if( rs.next() ) {
				int id = rs.getInt(1);
				String dataNascimento = rs.getString(4);
				return new Usuario( id, login, senha, dataNascimento );
			}
		} catch( SQLException e ) {
			throw new SelectException("Erro ao buscar Usuario");
		}
		return null;
	}
	
	public Usuario select( int usuario ) throws SelectException {
		try {
			selectId.setInt(1, usuario);
			ResultSet rs = select.executeQuery();
			if( rs.next() ) {
				int id = rs.getInt(1);
				String login = rs.getString(2);
				String senha = rs.getString(3);
				String dataNascimento = rs.getString(4);
				return new Usuario( id, login, senha, dataNascimento );
			}
		} catch (SQLException e) {
			throw new SelectException("Erro ao buscar usuario");
		}
		return null;
	}
	
	
	public List<Usuario> selectAll() throws SelectException {
		List<Usuario> usuarios = new LinkedList<>();
		try {
			ResultSet rs = selectAll.executeQuery();
			while(rs.next()) {
				int id = rs.getInt(1);
				String login = rs.getString(2);
				String senha = rs.getString(3);
				String dataNascimento = rs.getString(4);
				Usuario usuario = new Usuario( id, login, senha, dataNascimento );
				usuarios.add(usuario);
			}
			
		} catch (Exception e) {
			throw new SelectException("Erro ao buscar usuario");
		}
		return usuarios;
	}
	
	public void update(Usuario usuario) throws UpdateException {
		try {
			update.setString(1, usuario.getLogin());
			update.setString(2, usuario.getSenha());
			update.setString(3, usuario.getDataNascimento());
			update.setInt(4, usuario.getId());
		} catch( SQLException e ) {
			throw new UpdateException("Falha ao usuario");
		}
	}
	
	public void delete( Usuario usuario ) throws DeleteException {
		try {
			listaUsuarioDAO.delete(usuario);
			delete.setInt(1, usuario.getId());
			delete.executeUpdate();
		} catch( SQLException e ) {
			throw new DeleteException("Erro ao deletar usuario");
		}
	}
	
}
