package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;


import dados.Ator;
import exceptions.DeleteException;
import exceptions.InsertException;
import exceptions.SelectException;
import exceptions.UpdateException;

public class AtorDAO {
	private static AtorDAO instance = null;
	private static ElencoPDAO elencoPDAO;
	private static ElencoSDAO elencoSDAO;
	
	private PreparedStatement selectNewId;
	private PreparedStatement select;
	private PreparedStatement insert;
	private PreparedStatement selectAll;
	private PreparedStatement delete;
	private PreparedStatement update;
	
	public static AtorDAO getInstance() throws ClassNotFoundException, SQLException, SelectException {
		if( instance == null ) {
			instance = new AtorDAO();
		}
		return instance;
	}
	
	private AtorDAO() throws ClassNotFoundException, SQLException, SelectException {
		Connection conexao = Conexao.getConexao();
		selectNewId = conexao.prepareStatement("select nextval('ator_id')");
		insert = conexao.prepareStatement("insert into ator values (?,?,?,?)");
		select = conexao.prepareStatement("select * from ator where ator_id = ?");
		selectAll = conexao.prepareStatement("select * from ator");
		update = conexao.prepareStatement("update ator set nome = ?, data_nascimento = ?, sexo = ? where ator_id = ?");
		delete = conexao.prepareStatement("delete from lista_usuario where id_usuario = ?, id_lista = ?");
	}
	
	private int selectNewId() throws SelectException {
		try {
			ResultSet rs = selectNewId.executeQuery();
			if( rs.next() ) {
				return rs.getInt(1);
			}
		} catch( SQLException e ) {
			throw new SelectException("Erro ao buscar novo id da tabela filme");
		}
		return 0;
	}
	
	public void insert( Ator ator ) throws InsertException, SelectException {
		try {
			ator.setId(selectNewId());
			insert.setInt(1, ator.getId());
			insert.setString(2, ator.getNome());
			insert.setString(3, ator.getDataNascimento());
			insert.setString(4, ator.getSexo());			
			
			insert.executeUpdate();
		} catch( SQLException e ) {
			throw new InsertException("Erro ao inserir filme");
		}
	}
	
	public Ator select( int ator ) throws SelectException {
		try {
			select.setInt(1, ator);
			ResultSet rs = select.executeQuery();
			if( rs.next() ) {
				int id = rs.getInt(1);
				String nome = rs.getString(2);
				String dataNascimento = rs.getString(3);
				String sexo = rs.getString(4);
				return new Ator( id, nome, dataNascimento, sexo );
			}
		} catch( SQLException e ) {
			throw new SelectException("Erro ao buscar filme");
		}
		return null;
	}
	
	public List<Ator> selectAll() throws SelectException {
		List<Ator> atores = new LinkedList<>();
		try {
			ResultSet rs = selectAll.executeQuery();
			while( rs.next() ) {
				int id = rs.getInt(1);
				String nome = rs.getString(2);
				String dataNascimento = rs.getString(3);
				String sexo = rs.getString(4);
				Ator a = new Ator(id, nome, dataNascimento, sexo);
				atores.add(a);
			}
		} catch (SQLException e) {
			throw new SelectException("Erro ao buscar filme");
		}
		return atores;
	}
	
	public void update(Ator ator) throws UpdateException {
		try {
			update.setString(1, ator.getNome());
			update.setString(2, ator.getDataNascimento());
			update.setString(3, ator.getSexo());
			
			update.setInt(4, ator.getId());
		} catch( SQLException e ) {
			throw new UpdateException("Falha ao atualizar ator");
		}
	}
	
	public void delete( Ator ator ) throws DeleteException, ClassNotFoundException, SelectException {
		try {
			elencoPDAO = ElencoPDAO.getInstance();
			elencoSDAO = ElencoSDAO.getInstance();
			elencoPDAO.delete(ator);
			elencoSDAO.delete(ator);
			delete.setInt(1, ator.getId());
			delete.executeUpdate();
		} catch( SQLException e ) {
			throw new DeleteException("Erro ao deletar ator");
		}
	}
	
}
