package persistencia;

import java.awt.Image;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import javax.imageio.ImageIO;

import dados.Episodio;
import dados.Filme;
import dados.Serie;
import exceptions.DeleteException;
import exceptions.InsertException;
import exceptions.SelectException;
import exceptions.UpdateException;

public class EpisodioDAO {
	private static EpisodioDAO instance = null;
	private static ElencoPDAO elencoPDAO;
	private static ElencoSDAO elencoSDAO;
	private static FilmeSerieDAO filmeSerieDAO;
	
	private PreparedStatement selectNewId;
	private PreparedStatement select;
	private PreparedStatement insert;
	private PreparedStatement selectAll;
	private PreparedStatement delete;
	private PreparedStatement update;
	
	public static EpisodioDAO getInstance() throws ClassNotFoundException, SQLException, SelectException {
		if( instance == null ) {
			instance = new EpisodioDAO();
		}
		return instance;
	}
	
	private EpisodioDAO() throws ClassNotFoundException, SQLException, SelectException {
		elencoPDAO  = ElencoPDAO.getInstance();
		elencoSDAO  = ElencoSDAO.getInstance();
		Connection conexao = Conexao.getConexao();
		selectNewId = conexao.prepareStatement("select nextval('episodio_id')");
		insert      = conexao.prepareStatement("insert into episodio values (?,?,?,?,?)");
		select      = conexao.prepareStatement("select * from episodio where episodio_id = ?");
		selectAll   = conexao.prepareStatement("select * from episodio where filme_serie_id = ?");
		update      = conexao.prepareStatement("update episodio set titulo = ?, num_temp = ?,"
					+ " duracao = ?, serie_id = ? where episodio_id = ?");
		delete      = conexao.prepareStatement("delete from episodio where episodio_id = ?");
	}
	
	private int selectNewId() throws SelectException {
		try {
			ResultSet rs = selectNewId.executeQuery();
			if( rs.next() ) {
				return rs.getInt(1);
			}
		} catch( SQLException e ) {
			throw new SelectException("Erro ao buscar novo id da tabela filme");
		}
		return 0;
	}
	
	public void insert( Episodio ep ) throws InsertException, SelectException, ClassNotFoundException {
		try {
			filmeSerieDAO = FilmeSerieDAO.getInstance();
			ep.setId(selectNewId());
			ep.getSerie().cadastrarEp(ep);
			insert.setInt(1, ep.getId());
			insert.setString(2, ep.getTitulo());
			insert.setInt(3, ep.getNumTemp());
			insert.setInt(4, ep.getDuracao());
			insert.setInt(5, ep.getSerie().getId());
			try {
				filmeSerieDAO.update(ep.getSerie());
			} catch (UpdateException e) {
				System.out.println(e.getMessage());
			}
			
			insert.executeUpdate();
		} catch( SQLException e ) {
			throw new InsertException("Erro ao inserir episodio");
		}
	}
	
	public Episodio select( int ep ) throws SelectException, ClassNotFoundException {
		try {
			select.setInt(1, ep);
			ResultSet rs = select.executeQuery();
			if( rs.next() ) {
				int id = rs.getInt(1);
				String titulo = rs.getString(2);
				int numTemp = rs.getInt(3);
				int duracao = rs.getInt(4);
				Serie serie = (Serie)filmeSerieDAO.select(rs.getInt(5));
				return new Episodio( id, serie, titulo, numTemp, duracao );
			}
		} catch( SQLException e ) {
			throw new SelectException("Erro ao buscar episodio");
		}
		return null;
	}
	
	public List<Episodio> selectAll( Serie serie ) throws SelectException, ClassNotFoundException, SQLException {
		filmeSerieDAO = FilmeSerieDAO.getInstance();
		List<Episodio> eps = new LinkedList<>();
		try {
			selectAll.setInt(1, serie.getId());
			ResultSet rs = selectAll.executeQuery();
			while( rs.next() ) {
				int id = rs.getInt(1);
				String titulo = rs.getString(2);
				int numTemp = rs.getInt(3);
				int duracao = rs.getInt(4);
				Episodio ep = new Episodio( id, serie, titulo, numTemp, duracao );
				eps.add(ep);
			}
		} catch (SQLException e) {
			throw new SelectException("Erro ao buscar episodio");
		}
		return eps;
	}
	
	public void update(Episodio ep) throws UpdateException {
		try {
			update.setString(1, ep.getTitulo());
			update.setInt(2, ep.getNumTemp());
			update.setInt(3, ep.getDuracao());
			
			update.setInt(4, ep.getSerie().getId());
			
			update.setInt(5, ep.getId());
			
			try {
				filmeSerieDAO.update(ep.getSerie());
			} catch (UpdateException e) {
				System.out.println(e.getMessage());
			}
		} catch( SQLException e ) {
			throw new UpdateException("Falha ao atualizar filme");
		}
	}
	
	public void delete( Episodio ep ) throws DeleteException {
		try {
			if( ep.getSerie() != null ) {
				ep.getSerie().removerEp(ep);
			}
			delete.setInt(1, ep.getId());
			delete.executeUpdate();
			try {
				if( ep.getSerie() != null) {
					filmeSerieDAO.update(ep.getSerie());
				}
			} catch (UpdateException e) {
				System.out.println(e.getMessage());
			}
		} catch( SQLException e ) {
			throw new DeleteException("Erro ao deletar filme");
		}
	}
	
}
