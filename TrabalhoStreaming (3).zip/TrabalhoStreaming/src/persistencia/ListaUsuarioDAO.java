package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import dados.Filme;
import dados.Usuario;
import exceptions.DeleteException;
import exceptions.InsertException;
import exceptions.SelectException;
import exceptions.UpdateException;

public class ListaUsuarioDAO {
	private static ListaUsuarioDAO instance = null;
	private static FilmeSerieDAO filmeSerieDAO;
	
	private PreparedStatement select;
	private PreparedStatement insert;
	private PreparedStatement deleteUsuario;
	private PreparedStatement deleteFilme;
	private PreparedStatement update;
	private PreparedStatement deleteLista;
	
	public static ListaUsuarioDAO getInstance() throws ClassNotFoundException, SQLException, SelectException {
		if( instance == null ) {
			instance = new ListaUsuarioDAO();
		}
		return instance;
	}
	
	private ListaUsuarioDAO() throws ClassNotFoundException, SQLException, SelectException {
		Connection conexao = Conexao.getConexao();
		insert = conexao.prepareStatement("insert into lista_usuario values (?,?)");
		select = conexao.prepareStatement("select * from lista_usuario where usuario_id = ?");
		update = conexao.prepareStatement("update lista_usuario set usuario_id = ?, filme_serie_id = ?");
		deleteUsuario = conexao.prepareStatement("delete from lista_usuario where usuario_id = ?");
		deleteFilme = conexao.prepareStatement("delete from lista_usuario where filme_serie_id = ?");
		deleteLista = conexao.prepareStatement("delete from lista_usuario where usuario_id = ? and filme_serie_id = ?");
	}
	
	public void insert( Usuario usuario, Filme filme ) throws InsertException, SelectException, ClassNotFoundException {
		try {
			filmeSerieDAO = FilmeSerieDAO.getInstance();
			insert.setInt(1, usuario.getId());
			insert.setInt(2, filme.getId());
			insert.executeUpdate();
		} catch( SQLException e ) {
			throw new InsertException("Erro ao inserir usuario");
		}
	}
	
	public List<Filme> selectAll( int usuario ) throws SelectException, ClassNotFoundException {
		List<Filme> filmesLista = new LinkedList<>();
		try {
			filmeSerieDAO = FilmeSerieDAO.getInstance();
			select.setInt(1, usuario);
			ResultSet rs = select.executeQuery();
			while( rs.next() ) {
				int id = rs.getInt(2);
				filmesLista.add(filmeSerieDAO.select(id));
			}
		} catch( SQLException e ) {
			throw new SelectException("Erro ao buscar endereço da pessoa");
		}
		return filmesLista;
	}
	
	public void update(int usuario, int filme ) throws UpdateException {
		try {
			update.setInt(1, usuario);
			update.setInt(2, filme);
		} catch( SQLException e ) {
			throw new UpdateException("Falha ao atualizar rua");
		}
	}
	
	public void delete( Usuario usuario ) throws DeleteException {
		try {
			deleteUsuario.setInt(1, usuario.getId());
			deleteUsuario.executeUpdate();
		} catch( SQLException e ) {
			throw new DeleteException("Erro ao deletar usuario");
		}
	}
	
	public void delete( Filme filme ) throws DeleteException {
		try {
			deleteFilme.setInt(1, filme.getId());
			deleteFilme.executeUpdate();
		} catch( SQLException e ) {
			throw new DeleteException("Erro ao deletar filme");
		}
	}
	
	public void deleteLista( Usuario usuario, Filme filme ) throws DeleteException {
		try {
			deleteLista.setInt(1, usuario.getId());
			deleteLista.setInt(2, filme.getId());
			deleteLista.executeUpdate();
		} catch( SQLException e ) {
			throw new DeleteException("Erro ao deletar filme da lista");
		}
	}
	
}
