package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import dados.Ator;
import dados.Filme;
import exceptions.DeleteException;
import exceptions.InsertException;
import exceptions.SelectException;
import exceptions.UpdateException;

public class ElencoPDAO {
	private static ElencoPDAO instance = null;
	private static AtorDAO atorDAO;
	
	private PreparedStatement select;
	private PreparedStatement insert;
	private PreparedStatement deleteAtor;
	private PreparedStatement deleteFilme;
	private PreparedStatement update;
	
	public static ElencoPDAO getInstance() throws ClassNotFoundException, SQLException, SelectException {
		if( instance == null ) {
			instance = new ElencoPDAO();
		}
		return instance;
	}
	
	private ElencoPDAO() throws ClassNotFoundException, SQLException, SelectException {
		atorDAO = AtorDAO.getInstance();
		Connection conexao = Conexao.getConexao();
		insert = conexao.prepareStatement("insert into elencoP values (?,?)");
		select = conexao.prepareStatement("select * from elencoP where filme_serie_id = ?");
		update = conexao.prepareStatement("update elencoP set ator_id = ?, filme_serie_id = ?");
		deleteAtor = conexao.prepareStatement("delete from elencoP where ator_id = ?");
		deleteFilme = conexao.prepareStatement("delete from elencoP where filme_serie_id = ?");
	}
	
	public void insert( Ator ator, Filme filme ) throws InsertException, SelectException {
		try {
			insert.setInt(1, filme.getId());
			insert.setInt(2, ator.getId());
			insert.executeUpdate();
		} catch( SQLException e ) {
			throw new InsertException("Erro ao inserir usuario");
		}
	}
	
	public List<Ator> selectAll( int filme ) throws SelectException {
		List<Ator> atorLista = new LinkedList<>();
		try {
			select.setInt(1, filme);
			ResultSet rs = select.executeQuery();
			while( rs.next() ) {
				int id = rs.getInt(2);
				atorLista.add(atorDAO.select(id));
			}
		} catch( SQLException e ) {
			throw new SelectException("Erro ao buscar endereço da pessoa");
		}
		return atorLista;
	}
	
	public void update(int usuario, int filme ) throws UpdateException {
		try {
			update.setInt(1, usuario);
			update.setInt(2, filme);
		} catch( SQLException e ) {
			throw new UpdateException("Falha ao atualizar rua");
		}
	}
	
	public void delete( Ator ator ) throws DeleteException {
		try {
			deleteAtor.setInt(1, ator.getId());
			deleteAtor.executeUpdate();
		} catch( SQLException e ) {
			throw new DeleteException("Erro ao deletar ator");
		}
	}
	
	public void delete( Filme filme ) throws DeleteException {
		try {
			deleteFilme.setInt(1, filme.getId());
			deleteFilme.executeUpdate();
		} catch( SQLException e ) {
			throw new DeleteException("Erro ao deletar filme");
		}
	}
	
}
