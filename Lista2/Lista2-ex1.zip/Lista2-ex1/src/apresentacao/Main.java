package apresentacao;

import dados.Pessoa;
import negocio.Sistema;
import java.io.FileNotFoundException;
import java.io.File;
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;

public class Main {
	
	public static void menu() {
		System.out.println("Sair                         - Digite '-1'\n");
		System.out.println("Continuar inserindo          - Digite 0\n");
		System.out.println("Mostrar as pessoas inseridas - Digite 1\n\n");
	}
public static void main(String[] args) {
	Scanner sc;	
	Sistema informacoesPessoas = new Sistema();
	try {	
	File file = new File("infoPessoas.txt"); 
	sc = new Scanner(file);
	int escolha = -2;
	while (escolha != -1) {
		System.out.println("Faça sua escolha:\n");
		menu();
		escolha = Integer.parseInt(sc.nextLine());
		switch (escolha) {
		case -1:			
			System.out.println("Saindo...\n");
			break;
		case 0:
			Pessoa aux = new Pessoa();
			System.out.println("Digite o nome:\n");
			aux.setNome(sc.nextLine());
			System.out.println("Digite a idade:\n");
			aux.setIdade(Integer.parseInt(sc.nextLine()));
			System.out.println("Digite o CPF:\n");
			aux.setCpf(sc.nextLine());
			System.out.println("Digite a cidade:\n");
			aux.setCidade(sc.nextLine());
			informacoesPessoas.setPessoa(aux);
			break;
		case 1:
			List<Pessoa> ordenado = new ArrayList<Pessoa>();
			ordenado = informacoesPessoas.ordenarLista(informacoesPessoas.getCriancas());
			System.out.println("1 até 12: crianças;\n");
			for (Pessoa a : ordenado) {
				System.out.println(a.toString() + "\n");
			}
			System.out.println("13 até 18: adolescentes;\n");
			ordenado = informacoesPessoas.ordenarLista(informacoesPessoas.getAdolescentes());
			for (Pessoa a : ordenado) {
				System.out.println(a.toString() + "\n");
			}
			System.out.println("19 até 25: jovens;\n");
			ordenado = informacoesPessoas.ordenarLista(informacoesPessoas.getJovens());
			for (Pessoa a : ordenado) {
				System.out.println(a.toString() + "\n");
			}
			System.out.println("26 até 59: adultos;\n");
			ordenado = informacoesPessoas.ordenarLista(informacoesPessoas.getAdultos());
			for (Pessoa a : ordenado) {
				System.out.println(a.toString() + "\n");
			}
			System.out.println("60 ou mais: idosos;\n");
			ordenado = informacoesPessoas.ordenarLista(informacoesPessoas.getIdosos());
			for (Pessoa a : ordenado) {
				System.out.println(a.toString() + "\n");
			}
			break;
		default:
			System.out.println("Insira um numero valido!\n\n");
			break;
		}	
	}
sc.close();
		} catch (FileNotFoundException e) {
	sc = new Scanner(System.in);
	}
	sc = new Scanner(System.in);
	int escolha = -2;
	while (escolha != -1) {
		System.out.println("Faça sua escolha:\n");
		menu();
		escolha = Integer.parseInt(sc.nextLine());
		switch (escolha) {
		case -1:			
			System.out.println("Saindo...\n");
			break;
		case 0:
			Pessoa aux = new Pessoa();
			System.out.println("Digite o nome:\n");
			aux.setNome(sc.nextLine());
			System.out.println("Digite a idade:\n");
			aux.setIdade(Integer.parseInt(sc.nextLine()));
			System.out.println("Digite o CPF:\n");
			aux.setCpf(sc.nextLine());
			System.out.println("Digite a cidade:\n");
			aux.setCidade(sc.nextLine());
			informacoesPessoas.setPessoa(aux);
			break;
		case 1:
			List<Pessoa> ordenado = new ArrayList<Pessoa>();
			ordenado = informacoesPessoas.ordenarLista(informacoesPessoas.getCriancas());
			System.out.println("1 até 12: crianças;\n");
			for (Pessoa a : ordenado) {
				System.out.println(a.toString() + "\n");
			}
			System.out.println("13 até 18: adolescentes;\n");
			ordenado = informacoesPessoas.ordenarLista(informacoesPessoas.getAdolescentes());
			for (Pessoa a : ordenado) {
				System.out.println(a.toString() + "\n");
			}
			System.out.println("19 até 25: jovens;\n");
			ordenado = informacoesPessoas.ordenarLista(informacoesPessoas.getJovens());
			for (Pessoa a : ordenado) {
				System.out.println(a.toString() + "\n");
			}
			System.out.println("26 até 59: adultos;\n");
			ordenado = informacoesPessoas.ordenarLista(informacoesPessoas.getAdultos());
			for (Pessoa a : ordenado) {
				System.out.println(a.toString() + "\n");
			}
			System.out.println("60 ou mais: idosos;\n");
			ordenado = informacoesPessoas.ordenarLista(informacoesPessoas.getIdosos());
			for (Pessoa a : ordenado) {
				System.out.println(a.toString() + "\n");
			}
			break;
		default:
			System.out.println("Insira um numero valido!\n\n");
			break;
		}		
	}

	
	sc.close();
}
}
