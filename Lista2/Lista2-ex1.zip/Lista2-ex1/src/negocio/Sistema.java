package negocio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import dados.Pessoa;

public class Sistema {
private List<Pessoa> criancas = new ArrayList<Pessoa>();
private List<Pessoa> adolescentes = new ArrayList<Pessoa>();
private List<Pessoa> jovens = new ArrayList<Pessoa>();
private List<Pessoa> adultos = new ArrayList<Pessoa>();
private List<Pessoa> idosos = new ArrayList<Pessoa>();

public Sistema() {
	
}

public void setPessoa(Pessoa p) {
	if (p.getIdade() <= 12 && p.getIdade() >= 1) {
		this.criancas.add(p);
	}else if (p.getIdade() >= 13 && p.getIdade() <= 18) {
		this.adolescentes.add(p);
	}else if (p.getIdade() >=19 && p.getIdade() <= 25) {
		this.jovens.add(p);
	}else if (p.getIdade() >= 26 && p.getIdade() <= 59) {
		this.adultos.add(p);
	}else {
		this.idosos.add(p);
	}
}

public List<Pessoa> getCriancas() {
	return criancas;
}

public List<Pessoa> getAdolescentes() {
	return adolescentes;
}

public List<Pessoa> getJovens() {
	return jovens;
}

public List<Pessoa> getAdultos() {
	return adultos;
}

public List<Pessoa> getIdosos() {
	return idosos;
}

public List<Pessoa> ordenarLista(List<Pessoa> a){
	List<Pessoa> aux = new ArrayList<Pessoa>();
	aux = a;
	Collections.sort(aux);
	return aux;
}


}
