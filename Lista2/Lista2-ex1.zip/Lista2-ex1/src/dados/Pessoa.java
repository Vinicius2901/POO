package dados;

public class Pessoa implements Comparable<Pessoa> {
private String nome;
private int idade;
private String cpf;
private String cidade;

public Pessoa() {
	
}

public Pessoa(String nome, int idade, String cpf, String cidade) {
	this.nome = nome;
	this.idade = idade;
	this.cpf = cpf;
	this.cidade = cidade;
}

public String getNome() {
	return nome;
}

public int getIdade() {
	return idade;
}

public String getCpf() {
	return cpf;
}

public String getCidade() {
	return cidade;
}

public void setNome(String nome) {
	this.nome = nome;
}

public void setIdade(int idade) {
	this.idade = idade;
}

public void setCpf(String cpf) {
	this.cpf = cpf;
}

public void setCidade(String cidade) {
	this.cidade = cidade;
}


public String toString() {
	return "Pessoa [nome=" + nome + ", idade=" + idade + ", cpf=" + cpf + ", cidade=" + cidade + "]\n";
}

@Override
public int compareTo(Pessoa p) {
	if (p.nome.compareToIgnoreCase(this.nome) > 0) {
		return -1;
	}else if (p.nome.compareToIgnoreCase(this.nome) < 0) {
		return 1;
	}else {
	return 0;
	}
	}



}